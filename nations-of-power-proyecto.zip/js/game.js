const $=s=>document.querySelector(s),R=(a,b)=>a+Math.random()*(b-a),RI=(a,b)=>Math.floor(R(a,b+1)),pick=a=>a[RI(0,a.length-1)];
let mute=false,AC;
function tone(f,d,ty,v,dl){try{AC=AC||new AudioContext();const t=AC.currentTime+(dl||0),o=AC.createOscillator(),g=AC.createGain();o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d)}catch(e){}}
function snd(k){if(mute)return;({click:()=>tone(600,.06,'square',.05),tick:()=>tone(900,.03,'triangle',.06),coin:()=>{tone(988,.1,'sine',.1);tone(1319,.25,'sine',.1,.08)},war:()=>{tone(110,.7,'sawtooth',.12);tone(165,.7,'sawtooth',.1,.25)},peace:()=>{tone(523,.2,'sine',.1);tone(659,.3,'sine',.1,.15)},bad:()=>tone(150,.4,'square',.07),conq:()=>[392,523,392,659].forEach((x,i)=>tone(x,.25,'square',.07,i*.1)),event:()=>{tone(300,.15,'triangle',.1);tone(240,.3,'triangle',.1,.12)},notif:()=>tone(1500,.08,'sine',.08),turn:()=>{tone(880,.12,"sine",.1);tone(1175,.2,"sine",.1,.1)},win:()=>[523,659,784,1047].forEach((f,i)=>tone(f,.4,'triangle',.12,i*.18))}[k]||(()=>0))()}
$('#bMute').onclick=()=>{mute=!mute;$('#bMute').textContent=mute?'🔇 Sin sonido':'🔊 Sonido'};
document.addEventListener('click',e=>{if(e.target.tagName=='BUTTON')snd('click')});

const GM={Democracia:[1,1.15],Aristocracia:[1.05,1.05],'Monarquía':[1.05,1],Dictadura:[1.2,.9],'República':[1,1.1],Teocracia:[1.1,.95],'Oligarquía':[1.05,1.05],'Anarquía':[.9,.8]},GOVS=Object.keys(GM);
const CATS=[{k:'gdp',n:'Dinero (PIB)',g:()=>Math.round(Math.pow(10,R(9,12)))},{k:'area',n:'Territorio',g:()=>Math.random()<.06?17098246:RI(2000,7e6)},{k:'mil',n:'Poder militar',g:()=>RI(10,90)},{k:'pop',n:'Población',g:()=>Math.round(Math.pow(10,R(5.3,9.1)))},{k:'dem',n:'Poder democrático',g:()=>RI(5,95)},{k:'gov',n:'Tipo de política',g:()=>pick(GOVS)},{k:'tech',n:'Tecnología',g:()=>RI(10,90)},{k:'stab',n:'Estabilidad',g:()=>RI(10,90)},{k:'res',n:'Recursos',g:()=>RI(10,90)},{k:'pres',n:'Prestigio',g:()=>RI(10,90)}];
function fmt(k,v){if(k=='gdp')return'£'+(v>=1e12?(v/1e12).toFixed(2)+' billón':(v/1e9).toFixed(1)+' mil M');if(k=='area')return Math.round(v).toLocaleString('es')+' km²';if(k=='pop')return Math.round(v).toLocaleString('es');return typeof v=='number'?Math.round(v):v}

let room,net,host=false,me=null,myName='',started=false,players=[],ready={},S=null,lastSeq=-1,code='',isSolo=false;
function mkSolo(){const h={};return{emit(t,d){setTimeout(()=>(h[t]||[]).forEach(f=>f({peer:'me',isMe:true,data:d})),0)},on(t,f){(h[t]=h[t]||[]).push(f)}}}
function show(id){applyTheme(id);$("#bg").hidden=id=="game";['menu','lobby','wheel','game'].forEach(s=>$('#'+s).hidden=s!=id)}
const nm=()=>($('#nm').value.trim()||'Jugador'+RI(1,99));

/* ---------- red ---------- */
function wire(n){
 n.on('hello',m=>{if(m.isMe)me=m.peer;if(!host)return;const nx=String(m.data.name||'Jugador').slice(0,16);
  if(S||started){const r=S&&S.n.find(x=>x.wasH&&!x.h&&x.alive&&x.pname==nx);if(r){r.h=true;r.wasH=false;r.peer=m.peer;players=players.filter(p=>p.name!=nx);players.push({peer:m.peer,name:nx});L(`🔌 ${r.name} vuelve a la partida.`,'peace','sys');n.emit('lobby',{players,started:true,inGame:true,cfg:cfgTxt()});n.emit('state',S)}else{n.emit('lobby',{players,started:true,inGame:true,full:1,cfg:cfgTxt()});if(S)n.emit('state',S)}return}
  if(players.length>=8&&!players.find(p=>p.peer==m.peer))return;if(!players.find(p=>p.peer==m.peer))players.push({peer:m.peer,name:nx});n.emit('lobby',{players,started,cfg:cfgTxt()})});
 n.on('chat',m=>chatIn(m));n.on('rdy',m=>{$('#wait').textContent=`Nación lista. Esperando a los demás… (${m.data.k}/${m.data.t} listos)`});
 n.on('kick',m=>{const hp=players[0]&&players[0].peer;if(m.peer!=hp)return;if(m.data.peer==me){$('#lb1').innerHTML='<h3>⛔ El anfitrión te expulsó de la sala.</h3><button onclick="location.reload()">Volver al menú</button>'}else if(host){players=players.filter(p=>p.peer!=m.data.peer);n.emit('lobby',{players,started,cfg:cfgTxt()})}});
 n.on('lobby',m=>{players=m.data.players;if(m.data.cfg)CF=m.data.cfg;rLobby();if(m.data.started&&!started){started=true;if(!m.data.inGame)startWheel();else setTimeout(()=>{if(!S&&$('#wt'))$('#wt').textContent='👁 La partida ya empezó: entras como espectador (si te desconectaste, vuelve con el mismo nombre).'},1800)}});
 n.on('ready',m=>{if(!host||S)return;ready[m.peer]=m.data.stats;n.emit('rdy',{k:Object.keys(ready).length,t:players.length});if(players.every(p=>ready[p.peer])){S=build();n.emit('state',S)}});
 n.on('state',m=>{S=m.data;if(S.seq!==lastSeq){if(lastSeq>=0)snd(S.sfx=="turn"&&!(S.n[S.t]&&S.n[S.t].peer==me)?"":S.sfx);lastSeq=S.seq}if(isSolo){try{S.win?localStorage.removeItem('imp_save'):localStorage.setItem('imp_save',JSON.stringify(S))}catch(e){}}renderGame()});
 n.on('act',m=>{if(!host||!S||S.win)return;const a=S.n.find(x=>x.peer==m.peer);if(!a||S.t!=a.id||S.acts<=0)return;if(doAct(a,m.data.type,S.n[m.data.t],m.data)===true)S.acts--;chk();if(S.acts<=0&&!S.win)endTurn();n.emit('state',S)});
 n.on('endt',m=>{if(!host||!S||S.win)return;const a=S.n.find(x=>x.peer==m.peer);if(!a||S.t!=a.id)return;endTurn();n.emit('state',S)});
}
$('#bSolo').onclick=()=>{myName=nm();isSolo=true;host=true;net=mkSolo();wire(net);net.emit('hello',{name:myName});setTimeout(()=>net.emit('lobby',{players,started:true}),60)};
try{if(localStorage.getItem('imp_save'))$('#bCont').hidden=false}catch(e){}
$('#bCont').onclick=()=>{let v;try{v=JSON.parse(localStorage.getItem('imp_save'))}catch(e){}if(!v)return;myName=nm();isSolo=true;host=true;net=mkSolo();wire(net);net.emit('hello',{name:myName});v.dl=Date.now()+(v.tm||0)*1000;setTimeout(()=>net.emit('state',v),60)};
$('#bOn').onclick=async()=>{myName=nm();show('lobby');try{room=await claude.use('room')}catch(e){room=null}
 if(!room){$('#lb0').innerHTML='El modo online no está disponible en esta vista (hace falta abrir la página publicada con sesión iniciada).';return}
 room.presence({name:myName});room.on('invite',m=>{const me0=room.peers().find(p=>p.isMe);if(me0&&m.data.to==me0.peer)$('#inv').innerHTML=`<div class="pn">📨 <b>${esc(m.data.from)}</b> te invita<br><button id="ia">Aceptar</button></div>`,$('#ia').onclick=()=>{$('#inv').innerHTML='';enter(m.data.code,false)}});
 room.onPeers(()=>rLobby())};
const esc=s=>String(s).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[c]));
async function enter(c,h){code=c;host=h;net=await room.join(c);wire(net);$('#chat').hidden=false;try{net.onPeers(ch=>watchPeers(ch.peers))}catch(e){}$('#lb0').hidden=true;$('#lb1').hidden=false;$('#code').textContent=c;$('#bStart').hidden=!h;$('#invbox').hidden=!h;$('#wt').textContent=h?'':' Esperando a que el anfitrión empiece…';net.emit('hello',{name:myName})}
$('#bCreate').onclick=()=>enter('g'+Math.random().toString(36).slice(2,6),true);
$('#bJoin').onclick=()=>{const c=$('#jc').value.trim();if(c)enter(c,false)};
$('#bStart').onclick=()=>net.emit('lobby',{players,started:true});
function rLobby(){if(!$('#pl'))return;$('#pl').innerHTML=players.map((p,i)=>`<div class="pr">${i?'👤':'👑'} ${esc(p.name)}${p.peer==me?' <i style="color:var(--mu)">(tú)</i>':''}</div>`).join('')+`<div style="font-size:12px;color:var(--mu);margin-top:6px">${esc(CF)}</div>`;
 if(room&&host){const ps=room.peers().filter(p=>!p.isMe&&p.presence&&p.presence.name);$('#peers').innerHTML=ps.length?'':'<i style="color:var(--mu)">Nadie más conectado ahora. Comparte el código.</i>';ps.forEach(p=>{const b=document.createElement('button');b.className='s';b.textContent='Invitar a '+p.presence.name;b.onclick=()=>{room.emit('invite',{to:p.peer,code,from:myName});b.textContent='✔ Invitado';b.disabled=true};$('#peers').appendChild(b)})}}

/* ---------- ruleta ---------- */
let got={},spins=0,rot=0,spinning=false,wwin=-1;const SPD=window.__spd||1;
const ORDER=['gdp','area','pop','mil','dem','tech','stab','res','pres','gov'],ICON={gdp:'💰',area:'🗺',pop:'👥',mil:'🪖',dem:'🗳',tech:'🔬',stab:'⚖',res:'⛏',pres:'👑',gov:'🏛'},HUE={gdp:45,area:150,pop:200,mil:355,dem:215,tech:185,stab:260,res:28,pres:48,gov:280},S10=[10,20,30,40,50,60,75,90],
SEG={gdp:[1e9,5e9,1e10,5e10,1e11,2.5e11,5e11,1e12],area:[2e4,1e5,3e5,7e5,1.5e6,3e6,5e6,17098246],pop:[5e5,2e6,1e7,2.5e7,5e7,1e8,5e8,1.2e9],mil:S10,dem:[5,15,30,45,55,70,85,95],tech:S10,stab:S10,res:S10,pres:S10},
GB={Democracia:['dem',12,'Voto libre: +12 democracia'],Aristocracia:['pres',12,'Linaje noble: +12 prestigio'],'Monarquía':['stab',12,'Corona estable: +12 estabilidad'],Dictadura:['mil',14,'Mano dura: +14 poder militar'],'República':['tech',12,'Instituciones: +12 tecnología'],Teocracia:['stab',10,'Fe del pueblo: +10 estabilidad'],'Oligarquía':['gdp',.3,'Grandes fortunas: +30% PIB'],'Anarquía':['res',16,'Sin trabas: +16 recursos']},
sh=(k,v)=>{const f=x=>parseFloat(x.toFixed(1));if(k=='gov')return v;if(k=='gdp')return'£'+(v>=1e12?f(v/1e12)+' B':f(v/1e9)+' mM');if(k=='area')return v>=1e6?f(v/1e6)+' M km²':f(v/1e3)+' mil km²';if(k=='pop')return v>=1e9?f(v/1e9)+' mil M':v>=1e6?f(v/1e6)+' M':f(v/1e3)+' mil';return String(v)};
function startWheel(){show('wheel');wInit();renderGot()}
function wInit(){const k=ORDER[Math.min(spins,9)],c=CATS.find(x=>x.k==k);spinning=false;wwin=-1;$('#wi').innerHTML=`<span class="wic">${ICON[k]}</span><div class="wn">${c.n}</div><div class="ws">GIRO ${Math.min(spins+1,10)} DE 10</div>`;$('#wv').textContent='?';drawW()}
function renderGot(){$('#got').innerHTML=CATS.map(c=>`<div>${ICON[c.k]} ${c.n}<b>${got[c.k]===undefined?'—':fmt(c.k,got[c.k])}</b></div>`).join('')}
function drawW(){const c=$('#cv'),x=c.getContext('2d'),s=c.width/2,k=ORDER[Math.min(spins,9)],sg=k=='gov'?GOVS:SEG[k],n=sg.length,sa=Math.PI*2/n,h=HUE[k],R0=s-30;x.clearRect(0,0,c.width,c.height);
 let g=x.createRadialGradient(s,s,s*.7,s,s,s);g.addColorStop(0,'#8a5a12');g.addColorStop(.5,'#f5d27a');g.addColorStop(1,'#7a4b0c');x.fillStyle=g;x.beginPath();x.arc(s,s,s-4,0,7);x.fill();x.fillStyle='#0b1220';x.beginPath();x.arc(s,s,s-20,0,7);x.fill();
 const bl=Math.floor(rot/12);for(let i=0;i<24;i++){const a=i*Math.PI/12;x.fillStyle=(i+bl)%2?'#fff3b0':'#9a6a14';x.beginPath();x.arc(s+Math.cos(a)*(s-12),s+Math.sin(a)*(s-12),3.2,0,7);x.fill()}
 x.save();x.translate(s,s);x.rotate(rot*Math.PI/180);
 sg.forEach((v,i)=>{const a0=i*sa-Math.PI/2,a1=a0+sa,w=i==wwin,gr=x.createRadialGradient(0,0,30,0,0,R0);gr.addColorStop(0,`hsl(${h},60%,${w?50:i%2?24:16}%)`);gr.addColorStop(1,`hsl(${h},55%,${w?62:i%2?34:22}%)`);x.beginPath();x.moveTo(0,0);x.arc(0,0,R0,a0,a1);x.closePath();x.fillStyle=gr;x.fill();x.strokeStyle='#f5b94299';x.lineWidth=1.5;x.stroke();
  x.save();x.rotate((a0+a1)/2);x.textAlign='right';x.textBaseline='middle';x.font=(w?'bold 18px':'bold 15px')+' Georgia,serif';x.fillStyle=w?'#fff':'#f6e7b4';x.shadowColor='#000';x.shadowBlur=4;x.fillText(sh(k,v),R0-14,0);x.restore()});
 x.restore();g=x.createRadialGradient(s-6,s-6,2,s,s,38);g.addColorStop(0,'#fff0b0');g.addColorStop(1,'#a8670f');x.fillStyle=g;x.beginPath();x.arc(s,s,36,0,7);x.fill();x.fillStyle='#0b1220';x.beginPath();x.arc(s,s,29,0,7);x.fill();x.font='28px serif';x.textAlign='center';x.textBaseline='middle';(window.__ico&&__ico(x,ICON[k],s,s+2,34,'#f4ead0','#e6b755'))||x.fillText(ICON[k],s,s+2);
 x.shadowColor='#f5b942';x.shadowBlur=14;x.fillStyle='#f5b942';x.beginPath();x.moveTo(s-16,2);x.lineTo(s+16,2);x.lineTo(s,40);x.closePath();x.fill();x.strokeStyle='#fff3b0';x.lineWidth=2;x.stroke();x.shadowBlur=0}
function land(k,v,idx){wwin=idx;snd('coin');spins++;let msg='';
 if(k=='gov'){got.gov=v;const [bk,bv,tx]=GB[v];if(bk=='gdp')got.gdp=Math.round(got.gdp*(1+bv));else got[bk]=Math.min(95,got[bk]+bv);const rk=pick(['mil','dem','tech','stab','res','pres'].filter(q=>q!=bk)),rv=RI(6,14);got[rk]=Math.min(95,got[rk]+rv);msg=`🏛 ${v}: ${tx} · 🎲 Bonus aleatorio: ${CATS.find(q=>q.k==rk).n} +${rv}`;snd('win')}else got[k]=v;
 $('#wv').textContent=sh(k,v);$('#wb').textContent=msg;drawW();renderGot();
 if(spins==10){$('#bSpin').disabled=true;setTimeout(()=>{$('#wait').hidden=false;net.emit('ready',{stats:got})},2200/SPD)}else setTimeout(wInit,1300/SPD)}
$('#bSpin').onclick=()=>{if(spinning||spins>=10)return;spinning=true;const k=ORDER[spins],sg=k=='gov'?GOVS:SEG[k],n=sg.length,sa=360/n,idx=RI(0,n-1),jit=R(-.35,.35)*sa,from=rot,to=360*(Math.floor(from/360)+6)-((idx+.5)*sa+jit),t0=performance.now();let last=-1;
 (function f(t){const p=Math.min(1,(t-t0)/(3600/SPD)),e=1-Math.pow(1-p,4);rot=from+(to-from)*e;const cur=Math.floor((((-rot)%360)+360)%360/sa);if(cur!=last){last=cur;snd('tick')}drawW();if(p<1)requestAnimationFrame(f);else land(k,sg[idx],idx)})(t0)};

/* ---------- mundo ---------- */
const cnt=id=>S.own.filter(o=>o==id).length,area=n=>n.area0*cnt(n.id)/n.cells0,pw=n=>n.mil*(1+n.tech/100)*GM[n.gov][0]*(n.mob>0?1.2:1)*(n.techs.includes('arm')?1.1:1);
function nb(id){const s=new Set,{W,H,own}=S;for(let i=0;i<own.length;i++)if(own[i]==id){const x=i%W,y=i/W|0;[[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx,dy])=>{const X=x+dx,Y=y+dy;if(X>=0&&Y>=0&&X<W&&Y<H){const o=own[Y*W+X];if(o>=0&&o!=id)s.add(o)}})}return s}
function build(){const [W,H]=$('#cMap').value.split(',').map(Number),seed=RI(1,9999),tm=+$('#cTm').value,land=lands(W,H,seed),own=Array(W*H).fill(-1),tot=players.length+(+$('#cAI').value),seeds=[];let md=5;
 while(seeds.length<tot){const c=pick(land),cx=c%W,cy=c/W|0;if(seeds.every(s=>Math.hypot(s[0]-cx,s[1]-cy)>=md))seeds.push([cx,cy]);else if(Math.random()<.03)md=Math.max(1,md-.2)}
 land.forEach(c=>{let b=0,bd=1e9;seeds.forEach((s,i)=>{const d=Math.hypot(s[0]-c%W,s[1]-(c/W|0));if(d<bd){bd=d;b=i}});own[c]=b});
 const A=['Ar','Bel','Cor','Dra','Eld','Far','Gal','Hor','Ist','Kar','Lum','Mor','Nov','Ost','Pyr','Zan'],B=['ia','land','stan','ora','ovia','mark','esia'],n=[];
 for(let i=0;i<tot;i++){const h=i<players.length,st={};CATS.forEach(c=>st[c.k]=h?ready[players[i].peer][c.k]:c.g());
  n.push({id:i,name:h?'Imperio de '+players[i].name:pick(A)+pick(B),col:`hsl(${i*360/tot|0},${60+(i%3)*10}%,${46+(i%2)*8}%)`,h,peer:h?players[i].peer:null,pname:h?players[i].name:'',alive:true,...st,area0:st.area,cells0:own.filter(o=>o==i).length,ally:[],trade:[],war:[],pact:[],treaty:[],sanc:[],op:{},techs:[],rs:null,rp:0,inf:0,cul:0,cap:0,mob:0,miss:h?0:RI(0,2),pers:h?'':pick(PERS),cities:[]})}
 n.forEach((x,i)=>{const q=seeds[i];x.cities=[q[1]*W+q[0]];const ms=[];own.forEach((o,j)=>{if(o==i&&j!=x.cities[0])ms.push(j)});for(let k=0;k<2&&ms.length;k++)x.cities.push(ms.splice(RI(0,ms.length-1),1)[0])});
 return{pend:{},W,H,own,n,t:0,r:1,acts:3,log:[{r:1,t:'sys',s:'¡Comienza la partida!'}],win:null,seq:0,sfx:'win',yr:+$('#cEp').value,dy:+$('#cEp').value<1500?10:+$('#cEp').value<1900?5:2,ev:[],seed,tm,df:+$('#cDf').value,wf:{},rl:+$('#cRd').value,dl:Date.now()+tm*1000}}

const rel=(a,b,k)=>a[k].includes(b.id),link=(a,b,k)=>{if(!rel(a,b,k)){a[k].push(b.id);b[k].push(a.id)}},unlink=(a,b,k)=>{a[k]=a[k].filter(x=>x!=b.id);b[k]=b[k].filter(x=>x!=a.id)};
function L(s,f,t){S.log.unshift({q:S.seq,r:S.r,y:S.yr,t:t||({war:'war',peace:'dip',bad:'dip',coin:'eco',click:'eco'}[f])||'ev',s});S.log.length=Math.min(S.log.length,160);if(f)S.sfx=f;S.seq++}
function doAct(a,t,b,v){
 if(t=='mil'){a.mil=Math.min(200,a.mil*1.12);a.gdp*=.92;L(a.name+' refuerza su ejército.','click');return true}
 if(t=='eco'){a.gdp*=1.06;a.stab=Math.min(100,a.stab+2);L(a.name+' impulsa su economía.','coin');return true}
 if(t=='mkm'){if(!a.techs.includes('mis'))return false;a.gdp*=.98;a.miss++;L(`🚀 ${a.name} fabrica un misil (stock ${a.miss}).`,'click','war');return true}
 if(t=='mob'){if(a.mob>0)return false;a.mob=3;a.gdp*=.97;a.stab=Math.max(1,a.stab-2);L(`🪖 ${a.name} moviliza sus ejércitos 3 rondas (+20% fuerza, −3% PIB, −2 estabilidad).`,'click','war');return true}
 if(t=='res'){const T=TECH.find(x=>x.id==(v&&v.id));if(!T||a.techs.includes(T.id))return false;a.rs=T.id;L(`🔬 ${a.name} investiga «${T.n}».`,'click','tech');return true}
 if(t=='ch'){const p=S.pend[a.id],o=p&&p.opts[v&&v.i];if(!o)return false;a.gdp*=1-o.cost;L(`📋 ${a.name} decide: ${o.t}. Efectos: ${applyFx(a,p.fx,o.mit)}.`,'click','ev');delete S.pend[a.id];return 'free'}
 if(t=='dec')return decide(a,v);if(!b||!b.alive||b==a)return false;const w=rel(a,b,'war'),M=(s,f)=>L(s,f);
 if(t=='war'){if(w||rel(a,b,'ally'))return false;if(rel(a,b,'treaty')){unlink(a,b,'treaty');a.pres=Math.max(1,a.pres-15);a.stab=Math.max(1,a.stab-4);L(`📜 ${a.name} rompe su tratado con ${b.name}: pierde prestigio.`,'bad','dip')}unlink(a,b,'pact');link(a,b,'war');S.wf[wk(a.id,b.id)]={A:a.id,B:b.id,fr:0,o:{}};unlink(a,b,'trade');joinPacts(a,b);L(`¡${a.name} declara la guerra a ${b.name}!`,'war')}
 else if(t=='peace'){if(!w)return false;if(Math.random()<chance(a,b,'peace')){endWar(a,b);M(`${a.name} y ${b.name} firman la paz.`,'peace')}else M(`${b.name} rechaza la paz.`,'bad')}
 else if(t=='ally'){if(w||rel(a,b,'ally'))return false;if(Math.random()<chance(a,b,'ally')){link(a,b,'ally');M(`${a.name} y ${b.name} forman una alianza.`,'peace')}else M(`${b.name} rechaza la alianza.`,'bad')}
 else if(t=='trade'){if(w||rel(a,b,'trade'))return false;if(Math.random()<chance(a,b,'trade')){link(a,b,'trade');a.gdp*=1.04;b.gdp*=1.04;M(`${a.name} y ${b.name} pactan comercio.`,'coin')}else M(`${b.name} rechaza el pacto.`,'bad')}
 else if(t=='pact'){if(w||rel(a,b,'pact'))return false;if(Math.random()<chance(a,b,'pact')){link(a,b,'pact');addOp(a,b,10);addOp(b,a,10);L(`🛡 ${a.name} y ${b.name} firman un pacto de defensa mutua.`,'peace','dip')}else{addOp(b,a,-3);L(`${b.name} rechaza el pacto de defensa.`,'bad','dip')}}
 else if(t=='treaty'){if(w||rel(a,b,'treaty'))return false;if(Math.random()<chance(a,b,'ally')+.1){link(a,b,'treaty');L(`📜 ${a.name} y ${b.name} firman un tratado de no agresión.`,'peace','dip')}else L(`${b.name} rechaza el tratado.`,'bad','dip')}
 else if(t=='aid'){const g=a.gdp*.03;a.gdp-=g;b.gdp+=g*.8;addOp(b,a,20);L(`🎁 ${a.name} envía ayuda a ${b.name} (${fmt('gdp',g)}): su opinión mejora mucho.`,'coin','dip')}
 else if(t=='ask'){if(Math.random()<Math.max(.1,(op(b,a)+30)/130)+(rel(a,b,'ally')?.2:0)){const g=b.gdp*.025;b.gdp-=g;a.gdp+=g;addOp(b,a,-4);L(`🤲 ${b.name} concede ayuda a ${a.name} (${fmt('gdp',g)}).`,'coin','dip')}else{addOp(b,a,-2);L(`${b.name} rechaza ayudar a ${a.name}.`,'bad','dip')}}
 else if(t=='thr'){if(pw(a)>pw(b)*1.3&&Math.random()<.7){const g=b.gdp*.03;b.gdp-=g;a.gdp+=g;addOp(b,a,-25);a.pres=Math.max(1,a.pres-4);L(`😠 ${b.name} cede ante las amenazas de ${a.name} y paga tributo (${fmt('gdp',g)}).`,'war','dip')}else{addOp(b,a,-30);a.pres=Math.max(1,a.pres-6);L(`${b.name} ignora las amenazas de ${a.name} y se indigna (−6 prestigio).`,'bad','dip');if(!b.h&&!w&&Math.random()<.3&&!rel(a,b,'ally'))doAct(b,'war',a)}}
 else if(t=='sanc'){if(w)return false;const i=a.sanc.indexOf(b.id);if(i>=0){a.sanc.splice(i,1);L(`${a.name} levanta las sanciones a ${b.name}.`,'peace','dip')}else{a.sanc.push(b.id);unlink(a,b,'trade');addOp(b,a,-20);L(`🚫 ${a.name} sanciona a ${b.name}: −3% PIB/ronda para ${b.name}, −0,5% para ${a.name}.`,'war','dip')}}
 else if(t=='terr'){if(w)return false;const bc=bcells(a,b).filter(i=>!b.cities.includes(i));if(!bc.length)return false;const p=Math.min(.7,Math.max(.05,.15+op(b,a)/300+(pw(a)>pw(b)?.2:-.05)-(b.pers=='Defensiva'?.1:0)));if(Math.random()<p){S.own[bc[0]]=a.id;a.gdp*=.96;addOp(b,a,5);L(`🗺 ${b.name} cede una provincia a ${a.name} tras negociar (pago 4% PIB).`,'peace','dip')}else{addOp(b,a,-8);L(`${b.name} rechaza ceder territorio a ${a.name} (probabilidad ${Math.round(p*100)}%).`,'bad','dip')}}
 else if(t=='bomb'){if(!w||!a.techs.includes('mis')||a.miss<1)return false;a.miss--;const ci=b.cities.length&&Math.random()<.5;b.gdp*=ci?.95:.97;b.mil*=.94;b.stab=Math.max(1,b.stab-(ci?8:5));b.pop*=.99;addOp(b,a,-15);L(`🚀 ${a.name} bombardea ${ci?'una ciudad de ':''}${b.name}: −${ci?5:3}% PIB, −6% ejército, −${ci?8:5} estabilidad.`,'conq','war')}
 else if(t=='inv'){if(!w)return false;if(!assault(a,b,v&&v.c))return false}
 else if(t=='ord'){if(!w||!v||!v.v)return false;const wr=S.wf[wk(a.id,b.id)];if(wr)wr.o[a.id]=v.v;L(`${a.name} ordena estrategia ${v.v=='atk'?'ofensiva':v.v=='def'?'defensiva':'equilibrada'} contra ${b.name}.`,'click','war')}else return false;
 return true}
function combat(a,b){const pa=pw(a)*R(.75,1.25),pb=pw(b)*R(.75,1.25)*1.1,bc=cnt(b.id);
 if(pa>pb){const {W,own}=S,ac=new Set(),bord=[];own.forEach((o,i)=>{if(o==b.id){const x=i%W,y=i/W|0;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>own[(y+dy)*W+x+dx]==a.id&&x+dx>=0&&x+dx<W))bord.push(i)}});
  const k=Math.min(bord.length,Math.max(1,Math.ceil(bc*.18))),f=k/bc;bord.sort(()=>Math.random()-.5).slice(0,k).forEach(i=>own[i]=a.id);
  a.gdp+=b.gdp*f*.6;a.pop+=b.pop*f;b.gdp*=1-f;b.pop*=1-f;a.mil*=.92;b.mil*=.75;L(`💥 ${a.name} vence a ${b.name} y conquista ${k} regiones.`,'war');
  if(cnt(b.id)==0){b.alive=false;['ally','trade','war','pact','treaty'].forEach(r=>S.n.forEach(x=>x[r]=x[r].filter(i=>i!=b.id)));L(`☠ ${b.name} ha sido eliminada.`,'war')}}
 else{a.mil*=.8;b.mil*=.95;L(`🛡 ${b.name} repele el ataque de ${a.name}.`,'war')}}
function chk(){const al=S.n.filter(n=>n.alive),tot=S.own.filter(o=>o>=0).length,hs=al.filter(n=>n.h),th=S.n.filter(n=>n.h).length;
 for(const n of al){const v=vprog(n).find(x=>x[1]>=1);if(v&&!S.win)S.win=`Victoria ${v[0]} de ${n.name}: ${v[2]}.`}
 if(!S.win){if(!hs.length)S.win='Todos los jugadores han caído. Ganan las naciones ficticias.';else if(th>1&&hs.length==1)S.win=`Victoria de ${hs[0].name}: último jugador en pie.`;else if(al.length==1)S.win=`${al[0].name} conquistó el mundo.`}
 if(S.win){S.sfx='win';S.seq++}}
function endTurn(){const pp=S.pend[S.t];if(pp){applyFx(S.n[S.t],pp.fx,pp.opts[1].mit);L(`📋 ${S.n[S.t].name} no responde a la crisis: ${pp.tx}`,'bad','ev');delete S.pend[S.t]}if(S.n[S.t])L(S.n[S.t].name+' termina su turno.','','sys');let nx=S.n.find(n=>n.h&&n.alive&&n.id>S.t);if(!nx){roundAI();chk();nx=S.n.find(n=>n.h&&n.alive)}S.t=nx?nx.id:-1;S.acts=3;S.dl=Date.now()+S.tm*1000;if(nx)S.sfx='turn';S.seq++}
function roundAI(){
 S.n.filter(n=>n.alive).forEach(n=>{const tc=n.techs;
  n.gdp*=1+.02*GM[n.gov][1]+.01*n.trade.length+(tc.includes('ind')?.012:0)+(tc.includes('eco')?.008:0)+(n.h?-.005*S.df:.008*S.df);
  n.pop*=1+.004+(tc.includes('med')?.003:0)-(n.stab<30?.004:0);
  n.sanc.forEach(t=>{const x=S.n[t];if(x.alive){x.gdp*=.97;n.gdp*=.995}});
  n.mil=Math.min(200,n.mil*1.01+(n.gdp>1e11?.2:0));n.gdp=Math.min(n.gdp,5e12);n.pop=Math.min(n.pop,2e9);
  n.rp+=1+n.tech/12+(tc.includes('inf')?3:0);n.inf+=n.pres/8+n.ally.length*2+n.trade.length;n.cul+=(n.dem+n.pres)/30+(tc.includes('cul')?3:0)+n.res/50;if(n.mob>0)n.mob--;
  const T=TECH.find(t=>t.id==n.rs);if(T&&n.rp>=T.c){n.rp-=T.c;n.techs.push(T.id);n.rs=null;T.f(n);L(`🔬 ${n.name} completa «${T.n}».`,'coin','tech')}});
 S.n.filter(n=>n.alive&&!n.h).forEach(n=>{for(let i=0;i<1+(S.df>>1)&&n.alive;i++)ai(n)});
 events();disaster();warRound();
 const top=S.n.filter(n=>n.alive).sort((a,b)=>cnt(b.id)-cnt(a.id))[0];L(`Fin de la ronda ${S.r}: lidera ${top.name} con ${cnt(top.id)} regiones.`,'','sys');S.r++;S.yr+=S.dy;if(S.rl&&S.r>S.rl)limit()}
function pickTech(n){const l=TECH.filter(t=>!n.techs.includes(t.id));return l.length?(n.pers=='Tecnológica'?l[0]:pick(l)).id:null}
function ai(n){const P=n.pers,nbs=[...nb(n.id)].map(i=>S.n[i]).filter(x=>x.alive),en=nbs.filter(x=>rel(n,x,'war')),all=S.n.filter(x=>x.alive&&x!=n),r=Math.random(),tot=S.own.filter(o=>o>=0).length,
 W=k=>(({Agresiva:{war:.3,mil:.25},Expansionista:{war:.25,mil:.15},Imperialista:{war:.22,mil:.2,sanc:.1},'Diplomática':{ally:.3,aid:.12,trade:.15,pact:.1},Comercial:{trade:.4,ally:.1},Defensiva:{mil:.35,pact:.2},'Tecnológica':{res:.4}})[P]||{})[k]||0;
 if(!n.rs)n.rs=pickTech(n);
 if(n.techs.includes('mis')&&n.miss<2&&Math.random()<.3){doAct(n,'mkm');return}
 if(en.length&&r<.55){const e=en.sort((a,b)=>pw(a)-pw(b))[0];if(n.techs.includes('mis')&&n.miss>0&&Math.random()<.25)doAct(n,'bomb',e);else assault(n,e);return}
 if(en.length&&r<.65){doAct(n,'peace',en[0]);return}
 if((P=='Agresiva'||P=='Imperialista')&&Math.random()<.04+.02*S.df){const t=n.ally.map(i=>S.n[i]).filter(x=>x.alive&&pw(x)<pw(n))[0];if(t){unlink(n,t,'ally');L(`🗡 ${n.name} traiciona a su aliado ${t.name}.`,'war','dip');doAct(n,'war',t);return}}
 const top=[...all].sort((a,b)=>cnt(b.id)-cnt(a.id))[0];if(top&&top.h&&cnt(top.id)>tot*.3&&r<.2){doAct(n,rel(n,top,'war')?'peace':'sanc',top);return}
 const A=[['war',W('war')+.05*S.df],['ally',.1+W('ally')],['trade',.15+W('trade')],['aid',W('aid')],['pact',.04+W('pact')],['sanc',W('sanc')],['res',.12+W('res')],['mil',.18+W('mil')],['eco',.12],['thr',P=='Agresiva'||P=='Imperialista'?.08:.01]];
 let t=Math.random()*A.reduce((s,a)=>s+a[1],0),k='eco';for(const a of A){t-=a[1];if(t<=0){k=a[0];break}}
 if(k=='res'){n.rs=n.rs||pickTech(n);return}if(k=='mil'||k=='eco'){doAct(n,k);return}
 const c=k=='war'?nbs.filter(x=>!rel(n,x,'ally')&&!rel(n,x,'war')&&!rel(n,x,'treaty')&&pw(x)<pw(n)*(P=='Agresiva'||P=='Expansionista'||P=='Imperialista'?1.3:.9)):all;if(c.length)doAct(n,k,pick(c))}
/* ---------- interfaz de juego ---------- */
let selT=null,selC=null;
function renderGame(){show('game');const m=S.n.find(n=>n.peer==me),cur=S.n[S.t],my=!!m&&!!cur&&cur.peer==me&&!S.win;
 $('#hdr').className='c'+(my?' my':'');$('#hdr').innerHTML=`📅 AÑO <b>${S.yr}</b> <small>· ${era(S.yr)} · RONDA ${S.r}${S.rl?'/'+S.rl:''}</small>`;$('#tb').innerHTML=`Ronda <b>${Math.min(S.r,S.rl||S.r)}${S.rl?'/'+S.rl:''}</b>${S.rl&&S.r>=S.rl-2?' <b style="color:#f43f5e">⚠ últimas rondas</b>':''} · Turno de <b style="color:${cur?cur.col:'#fff'}">${cur?esc(cur.name):'—'}</b> · Acciones: <b>${S.acts}</b> · ⏱ <b id="tt"></b>${my?' · <b style="color:var(--ac)">¡TU TURNO!</b>':''}`;
 if(m)$('#me').innerHTML=[['Dinero',fmt('gdp',m.gdp)],['Territorio',fmt('area',area(m))],['Poder militar',fmt('mil',pw(m))],['Población',fmt('pop',m.pop)],['Política',m.gov],['Dem.',m.dem],['Estabilidad',m.stab],['Regiones',cnt(m.id)+' / '+S.own.filter(o=>o>=0).length]].map(([a,b])=>`<div>${a}<b>${b}</b></div>`).join('')+(m.alive?'':'<div><b>☠ Eliminado</b></div>');
 if(m)$('#me').insertAdjacentHTML('beforeend',['stab','dem','res','tech','pres'].map(k=>`<div style="grid-column:1/-1">${LB[k]} ${Math.round(m[k])}<div style="height:5px;background:#1b2a4a;border-radius:3px"><div style="height:5px;width:${Math.min(100,m[k])}%;background:var(--ac);border-radius:3px"></div></div></div>`).join(''));const sel=$('#tg');if(sel.options.length!=S.n.length){selT=null;sel.innerHTML=S.n.map(n=>`<option value="${n.id}">${esc(n.name)}</option>`).join('')}if(selT!==null)sel.value=selT;sel.onchange=()=>selT=sel.value;
 const tn=S.n[sel.value];$('#ch').textContent=m&&tn&&tn!=m&&tn.alive?`Alianza ${Math.round(chance(m,tn,'ally')*100)}% · Comercio ${Math.round(chance(m,tn,'trade')*100)}% · Paz ${Math.round(chance(m,tn,'peace')*100)}%`:'';document.querySelectorAll('[data-a]').forEach(b=>{const a=b.dataset.a;b.disabled=!my||(!['mkm','mob'].includes(a)&&(!tn||!tn.alive||tn==m))||(['inv','bomb'].includes(a)&&!(tn&&rel(m,tn,'war')))||(a=='bomb'&&(!m.techs.includes('mis')||m.miss<1))||(a=='mkm'&&!m.techs.includes('mis'))||(a=='mob'&&m.mob>0)});
 $('#bEnd').disabled=!my;
 $('#nt').innerHTML='<tr><th>Nación</th><th>Poder</th><th>Reg.</th><th></th></tr>'+S.n.map(n=>`<tr style="opacity:${n.alive?1:.35}"><td><span style="color:${n.col}">■</span> ${esc(n.name)}${n.h?' 👤':''}</td><td>${Math.round(pw(n))}</td><td>${cnt(n.id)}</td><td>${m&&n!=m?(rel(m,n,'war')?'⚔':'')+(rel(m,n,'ally')?'🤝':'')+(rel(m,n,'trade')?'💱':''):''}</td></tr>`).join('');
 renderLog(m);renderWar(m);renderChat(m);renderPro(m);$('#chips').innerHTML=S.n.filter(n=>n.h).map(n=>`<span class="chip${n.id==S.t?' on':''}" style="${n.alive?'':'opacity:.4'}">${n.id==S.t?'▶ ':''}${esc(n.name.replace('Imperio de ',''))}${n.alive?'':' ☠'}</span>`).join('');drawMap(m);
 const key=S.r+'-'+S.t;if(m&&my&&key!=tk){tk=key;if(snap&&!S.win)showRep(m);snap={q:S.seq,g:m.gdp,p:m.pop,w:pw(m),c:cnt(m.id),s:m.stab}}$('#logp').classList.toggle('wait',!my);
 if(S.win){$('#et').textContent=S.win;$('#end').hidden=false}}
const hs=(x,y,s)=>{const h=Math.sin(x*127.1+y*311.7+s*74.7)*43758.5453;return h-Math.floor(h)};
function vn(x,y,s){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=hs(xi,yi,s),b=hs(xi+1,yi,s),c=hs(xi,yi+1,s),d=hs(xi+1,yi+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
function fbm(x,y,s,o){let t=0,a=.5,f=1,n=0;for(let i=0;i<o;i++){t+=a*vn(x*f,y*f,s+i*17);n+=a;a/=2;f*=2}return t/n}
function lands(W,H,seed){const sc=[];for(let y=0;y<H;y++)for(let x=0;x<W;x++){const d=Math.hypot((x-W/2)/W*2,(y-H/2)/H*2);sc.push({i:y*W+x,v:fbm(x/W*4.5,y/H*3,seed,5)-d*.5})}sc.sort((a,b)=>b.v-a.v);return sc.slice(0,Math.floor(W*H*.55)).map(o=>o.i)}
function hsl(c){const [h,s,l]=c.match(/[\d.]+/g).map(Number),a=s/100*Math.min(l/100,1-l/100),f=n=>{const k=(n+h/30)%12;return Math.round(255*(l/100-a*Math.max(-1,Math.min(k-3,9-k,1))))};return[f(0),f(8),f(4)]}
function chance(a,b,t){const o=(b.op[a.id]||0)/200,dm=1-Math.abs(a.dem-b.dem)/100,P=b.pers,f=P=='Diplomática'?.12:P=='Agresiva'?-.12:0,c=P=='Comercial'?.15:0,K=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
 if(t=='ally')return K(.2+.4*dm+a.pres/400+o+f+(a.war.some(w=>b.war.includes(w))?.15:0),.03,.9);if(t=='pact')return K(.15+.3*dm+a.pres/500+o+f+(rel(a,b,'ally')?.25:0),.03,.8);if(t=='trade')return K(.4+.3*dm+a.pres/500+o+c,.05,.95);if(t=='peace')return K((pw(b)<pw(a)?.65:.35)+o,.05,.9);return 1}
function limit(){const sc=n=>cnt(n.id)*10+n.gdp/2e10+n.pop/2e7+pw(n),al=S.n.filter(n=>n.alive).sort((a,b)=>sc(b)-sc(a));S.win=`Límite de ${S.rl} rondas alcanzado. Gana ${al[0].name} por puntuación (${Math.round(sc(al[0]))} pts).`;S.sfx='win';S.seq++}
function events(){const nE=RI(1,2+S.df);for(let i=0;i<nE;i++){const al=S.n.filter(x=>x.alive),hh=al.filter(x=>x.h),n=Math.random()<.12*S.df&&hh.length?pick(hh):pick(al),[nm,vb,fx]=pick(ET),[iw,k]=pick(EI),cs=pick(EC),V=Object.values(fx),neg=V.filter(v=>v<0).length>=V.filter(v=>v>0).length,tx=`${nm}: ${n.name} ${vb} (${iw}) ${cs}`;
 if(n.h&&neg&&!S.pend[n.id]){S.pend[n.id]={tx,fx,opts:[{t:'Respuesta de emergencia (−3% PIB, reduce el daño un 60%)',cost:.03,mit:k*.4},{t:'Dejar que siga su curso (sin coste)',cost:0,mit:k}]};L(`📋 ${tx}. Requiere una decisión.`,'event','ev')}else L(`${tx}. Efectos: ${applyFx(n,fx,k)}.`,'event','ev')}}
let lf='all',thc='auto',scr='menu';const ACS={menu:['#f5b942','#0b1220'],lobby:['#4fd1c5','#071a1d'],wheel:['#e879f9','#1a0b24'],game:['#7bd88f','#0a1424']};
function applyTheme(id){scr=id||scr;const r=document.documentElement.style,a=ACS[scr];r.setProperty('--ac',thc=='auto'?a[0]:thc);r.setProperty('--bg',a[1])}
function renderLog(m){const fl=S.log.filter(e=>lf=='all'||(lf=='me'?m&&e.s.includes(m.name):e.t==lf));let h='',lr=-1;fl.forEach(e=>{if(e.r!=lr){lr=e.r;h+=`<div class="rh">— RONDA ${e.r}${e.y?' · AÑO '+e.y:''} —</div>`}h+=`<div class="lg ${e.t}${m&&e.s.includes(m.name)?' me':''}">${esc(e.s)}</div>`});$('#log').innerHTML=h||'<i style="color:var(--mu)">Sin eventos.</i>'}
document.querySelectorAll('#lf button').forEach(b=>b.onclick=()=>{lf=b.dataset.f;document.querySelectorAll('#lf button').forEach(z=>z.classList.toggle('on',z==b));if(S)renderLog(S.n.find(n=>n.peer==me))});
$('#cTh').onchange=e=>{thc=e.target.value;applyTheme()};applyTheme('menu');
const LB={gdp:'PIB',pop:'población',mil:'poder militar',stab:'estabilidad',res:'recursos',tech:'tecnología',pres:'prestigio',dem:'democracia'};
const era=y=>y<500?'Antigüedad':y<1500?'Edad Media':y<1800?'Era Moderna':y<1945?'Era Industrial':y<2000?'Era Contemporánea':'Era Digital';
let snap=null,tk='';
function showRep(m){const E=S.log.filter(e=>e.q>=snap.q&&(e.t!='sys'||e.s.startsWith('Fin de'))).reverse(),me=e=>e.s.includes(m.name),row=e=>`<div class="lg ${e.t}${me(e)?' me':''}">${esc(e.s)}</div>`,
 d=(a,b,l,fn)=>{const v=b-a;return `<tr><td>${l}</td><td>${fn(a)}</td><td>→ ${fn(b)}</td><td style="color:${v>0?'#4ade80':v<0?'#f87171':'var(--mu)'}">${v>0?'▲':v<0?'▼':'•'}</td></tr>`};
 $('#rpb').innerHTML=`<h2 style="margin:0;color:var(--ac)">📰 Informe del mundo · Año ${S.yr}</h2><div style="color:var(--mu);font-size:12px">Lo ocurrido desde tu último turno</div><table>${d(snap.g,m.gdp,'PIB',v=>fmt('gdp',v))}${d(snap.p,m.pop,'Población',v=>fmt('pop',v))}${d(snap.w,pw(m),'Poder militar',v=>Math.round(v))}${d(snap.c,cnt(m.id),'Regiones',v=>v)}${d(snap.s,m.stab,'Estabilidad',v=>Math.round(v))}</table><b>⚠ Te afecta</b>${E.filter(me).map(row).join('')||'<div style="color:var(--mu)">Nada directo.</div>'}<b>🌐 Resto del mundo</b>${E.filter(e=>!me(e)).map(row).join('')||'—'}<p class="c"><button id="rpc">Continuar</button></p>`;$('#rp').hidden=false;$('#rpc').onclick=()=>$('#rp').hidden=true;snd('turn')}
function disaster(){S.ev=(S.ev||[]).filter(e=>e.r>=S.r-2);const land=[];S.own.forEach((o,i)=>{if(o>=0)land.push(i)});const nd=Math.random()<.45+.1*S.df?(Math.random()<.3?2:1):0,
 D=[['🌪','un tornado devasta',n=>{n.gdp*=.98;n.pop*=.99;return'−2% PIB, −1% población'}],['🌋','una erupción volcánica arrasa',n=>{n.gdp*=.96;n.pop*=.98;n.res=Math.max(1,n.res-3);return'−4% PIB, −2% población, −3 recursos'}],['🌍','un terremoto sacude',n=>{n.gdp*=.95;n.pop*=.97;n.stab=Math.max(1,n.stab-5);return'−5% PIB, −3% población, −5 estabilidad'}],['🌊','una inundación anega',n=>{n.gdp*=.97;n.res=Math.max(1,n.res-2);return'−3% PIB, −2 recursos'}],['☀','una sequía castiga',n=>{n.pop*=.98;n.gdp*=.97;n.res=Math.max(1,n.res-4);return'−3% PIB, −2% población, −4 recursos'}],['🔥','un incendio forestal consume',n=>{n.res=Math.max(1,n.res-5);n.gdp*=.99;return'−5 recursos, −1% PIB'}],['🦠','un brote epidémico golpea',n=>{n.pop*=.96;n.stab=Math.max(1,n.stab-4);return'−4% población, −4 estabilidad'}]];
 for(let k=0;k<nd;k++){const c=pick(land),n=S.n[S.own[c]],d=pick(D),r=d[2](n);S.ev.push({c,i:d[0],r:S.r});L(`${d[0]} ${d[1]} una región de ${n.name}: ${r}.`,'bad','ev')}}
const PERS=['Agresiva','Diplomática','Comercial','Expansionista','Defensiva','Imperialista','Tecnológica'];
const TECH=[{id:'ind',n:'Industrialización',c:30,d:'+1,2% crecimiento del PIB',f:n=>0},{id:'arm',n:'Armamento moderno',c:40,d:'+10% poder militar y +8 ejército',f:n=>n.mil+=8},{id:'mis',n:'Misiles balísticos',c:60,d:'Desbloquea bombardeo (+3 misiles)',f:n=>n.miss+=3},{id:'inf',n:'Informática',c:50,d:'+3 PI por ronda, +6 tecnología',f:n=>n.tech=Math.min(100,n.tech+6)},{id:'dip',n:'Diplomacia internacional',c:35,d:'+8 prestigio',f:n=>n.pres=Math.min(100,n.pres+8)},{id:'cul',n:'Industria cultural',c:45,d:'+3 cultura por ronda',f:n=>0},{id:'eco',n:'Mercados globales',c:40,d:'+0,8% crecimiento del PIB',f:n=>0},{id:'med',n:'Medicina moderna',c:35,d:'+0,3% crecimiento de población, +4 estabilidad',f:n=>n.stab=Math.min(100,n.stab+4)}];
const ET=[['💥 Crisis económica','sufre una crisis bancaria',{g:-.06,s:-4}],['📈 Boom económico','vive un auge de exportaciones',{g:.06,s:2}],['⛽ Crisis energética','sufre una crisis energética',{g:-.04,s:-3,r:-3}],['🛢 Petróleo','descubre grandes yacimientos de petróleo',{g:.05,r:6}],['🔬 Descubrimiento tecnológico','logra un avance científico',{t:5,e:2}],['✊ Revolución','vive una revolución',{s:-20,m:-8,d:6}],['🪖 Golpe de Estado','sufre un golpe de Estado',{s:-18,m:-4,d:-8}],['🦠 Pandemia','sufre una pandemia',{p:-.04,g:-.03,s:-4}],['⚔ Guerra civil','cae en una guerra civil',{m:-12,s:-15,p:-.03,g:-.05}],['📢 Protestas','sufre protestas masivas',{s:-7}],['🗳 Elecciones','celebra elecciones',{d:3,s:3}],['💸 Corrupción','destapa una trama de corrupción',{s:-6,g:-.02,e:-3}],['🎭 Escándalo político','sufre un escándalo político',{e:-6,s:-3}],['🚧 Conflicto fronterizo','sufre un conflicto fronterizo',{m:-3,s:-2}],['🏭 Huelga general','sufre una huelga general',{g:-.03,s:-4}],['🎨 Auge cultural','vive un auge cultural',{c:6,e:3}],['🌾 Hambruna','sufre una hambruna',{p:-.03,s:-8}],['💻 Ciberataque','sufre un ciberataque',{g:-.03,t:-2}],['🌍 Migración','recibe una oleada migratoria',{p:.02,s:-3,g:.01}],['🏦 Inversión extranjera','recibe inversión extranjera',{g:.04,e:2}],['🏖 Turismo','disfruta de un auge turístico',{g:.03,e:2}],['⛏ Minería','descubre yacimientos mineros',{r:5,g:.02}],['🕵 Espionaje','destapa una red de espionaje',{e:-4,m:-2}],['🎓 Reforma educativa','aprueba una reforma educativa',{t:4,s:2,g:-.01}],['🛡 Reforma militar','moderniza sus fuerzas',{m:6,g:-.015}],['🤝 Acuerdo energético','firma un acuerdo energético',{g:.03,r:3}],['🌡 Ola de calor','sufre una ola de calor',{p:-.01,r:-3,s:-2}],['🏛 Reforma política','aprueba reformas políticas',{d:5,s:-2}]];
const EC=['tras meses de tensión','por sorpresa','en plena campaña electoral','durante un duro invierno','mientras el mundo observa','bajo presión internacional','tras años de desinversión','entre rumores de guerra'],EI=[['leve',.6],['moderada',1],['grave',1.5]];
function applyFx(n,f,k){k=k??1;const o=[],NM={m:['mil','poder militar'],s:['stab','estabilidad'],t:['tech','tecnología'],r:['res','recursos'],e:['pres','prestigio'],d:['dem','democracia'],c:['cul','cultura']};for(const x in f){let v=f[x]*k;if(x=='g'){n.gdp*=1+v;o.push(`PIB ${(v*100).toFixed(1)}%`)}else if(x=='p'){n.pop*=1+v;o.push(`población ${(v*100).toFixed(1)}%`)}else{v=Math.round(v);const key=NM[x][0];if(key=='cul')n.cul=Math.max(0,n.cul+v);else n[key]=Math.max(1,Math.min(key=='mil'?200:100,n[key]+v));o.push(`${v>0?'+':''}${v} ${NM[x][1]}`)}}return o.join(', ')}
const op=(a,b)=>a.op[b.id]||0,addOp=(a,b,v)=>a.op[b.id]=Math.max(-100,Math.min(100,op(a,b)+v));
function joinPacts(a,b){const j=(x,y)=>x.pact.forEach(i=>{const p=S.n[i];if(p.alive&&p!=y&&!rel(p,y,'war')&&!rel(p,y,'ally')&&Math.random()<(p.h?.5:.75)){link(p,y,'war');S.wf[wk(p.id,y.id)]={A:p.id,B:y.id,fr:0,o:{}};L(`🛡 ${p.name} entra en guerra contra ${y.name} por su pacto de defensa con ${x.name}.`,'war','war')}});j(b,a);j(a,b)}
function bcells(a,b){const {W,own}=S,r=[];own.forEach((o,i)=>{if(o==b.id){const x=i%W,y=i/W|0;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>x+dx>=0&&x+dx<W&&own[(y+dy)*W+x+dx]==a.id))r.push(i)}});return r}
function assault(a,b,c){const bc=bcells(a,b);if(!bc.length)return false;if(c==null||!bc.includes(c))c=bc.find(i=>b.cities.includes(i))??pick(bc);
 const {W,own}=S,x=c%W,y=c/W|0,dp=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>x+dx>=0&&x+dx<W&&own[(y+dy)*W+x+dx]==b.id).length,cb=b.cities.includes(c)?(b.cities[0]==c?.9:.5):0,st=(S.wf[wk(a.id,b.id)]||{o:{}}).o,
 pa=pw(a)*.4*(st[a.id]=='atk'?1.25:1)*R(.7,1.3),pb=pw(b)*.4*(st[b.id]=='def'?1.3:1)*(1+.12*dp+cb)*R(.7,1.3),nm=cb?(b.cities[0]==c?'la CAPITAL':'una ciudad'):'una provincia';
 if(pa>pb){own[c]=a.id;a.mil*=1-.05*R(.5,1.5);b.mil*=1-.04*R(.5,1.5);b.pop*=.99;L(`⚔ ${a.name} ataca ${nm} de ${b.name} (fuerza ${Math.round(pa)} vs defensa ${Math.round(pb)}): ¡CONQUISTADA!`,'conq','war');
  if(cb){const i=b.cities.indexOf(c);b.cities.splice(i,1);a.cities.push(c);a.cap++;b.stab=Math.max(1,b.stab-15);b.gdp*=.92;a.pres=Math.min(100,a.pres+3);addOp(b,a,-30);L(`🏙 ${a.name} captura ${nm} de ${b.name}: ${b.name} pierde 15 de estabilidad y 8% del PIB.`,'conq','war')}
  if(cnt(b.id)==0){b.alive=false;['ally','trade','war','pact','treaty'].forEach(r=>S.n.forEach(z=>z[r]=z[r].filter(i=>i!=b.id)));L(`☠ ${b.name} ha sido eliminada.`,'war')}}
 else{a.mil*=1-.07*R(.5,1.5);b.mil*=1-.02*R(.5,1.5);L(`🛡 ${b.name} repele el ataque de ${a.name} contra ${nm} (fuerza ${Math.round(pa)} vs defensa ${Math.round(pb)}).`,'war')}return true}
function vprog(n){const tot=S.own.filter(o=>o>=0).length,c=cnt(n.id);return[['🗺 Conquista del mundo',c/(tot*.75),`${Math.round(c/tot*100)}% del mapa (meta 75%: ${Math.ceil(tot*.75)} provincias, tienes ${c})`]]}
function renderPro(m){if(!m)return;const cur=S.n[S.t],tn=S.n[selT??-1],my=cur&&cur.id==m.id&&!S.win;
 $('#top').innerHTML=[['💰',fmt('gdp',m.gdp),'PIB'],['👥',fmt('pop',m.pop),'Población'],['🪖',Math.round(pw(m)),'Poder militar'],['🚀',m.miss,'Misiles'],['🔬',Math.round(m.rp)+' PI','Puntos de investigación'],['⭐',Math.round(m.pres),'Prestigio'],['⚖',Math.round(m.stab),'Estabilidad'],['🏙',m.cities.length,'Ciudades']].map(([i,v,t])=>`<span class="rs" title="${t}">${i} <b>${v}</b></span>`).join('');
 $('#info').innerHTML=tn?`<b style="color:${tn.col}">${esc(tn.name)}</b>${tn.h?' 👤':''}<br>${tn.pers?'🎭 '+tn.pers+'<br>':''}Poder ${Math.round(pw(tn))} · PIB ${fmt('gdp',tn.gdp)}<br>${tn.gov} · ${tn.cities.length} ciudades<br>${tn!=m?`Opinión de ellos: <b>${Math.round(tn.op[m.id]||0)}</b><br>${rel(m,tn,'war')?'⚔ En guerra':rel(m,tn,'ally')?'🤝 Aliados':rel(m,tn,'pact')?'🛡 Pacto de defensa':rel(m,tn,'trade')?'💱 Comercio':'Neutral'}${rel(m,tn,'treaty')?' · 📜 Tratado':''}${m.sanc.includes(tn.id)?' · 🚫 Sancionado':''}`:'Tu nación'}`:'<i>Toca una nación en el mapa</i>';
 $('#tl').innerHTML=TECH.map(t=>{const d=m.techs.includes(t.id),r=m.rs==t.id;return `<div class="lg ${d?'eco':r?'ev':'sys'}"><b>${t.n}</b> · ${t.c} PI<br><span style="color:var(--mu);font-size:12px">${t.d}</span><br>${d?'✅ Investigada':r?'🔬 En curso: '+Math.round(m.rp)+'/'+t.c:`<button class="s" data-r="${t.id}" ${my?'':'disabled'}>Investigar</button>`}</div>`}).join('');
 document.querySelectorAll('[data-r]').forEach(b=>b.onclick=()=>net.emit('act',{type:'res',id:b.dataset.r}));
 $('#evl').innerHTML=S.log.filter(e=>e.t=='ev'||e.t=='tech').slice(0,10).map(e=>`<div class="lg ${e.t}">${esc(e.s)}</div>`).join('')||'—';
 $('#vp').innerHTML=vprog(m).map(([n,p,d])=>`<div style="margin:6px 0">${n} <span style="color:var(--mu);font-size:12px">${d}</span><div class="bar"><i style="width:${Math.min(100,p*100)}%"></i></div></div>`).join('');
 const pd=S.pend&&S.pend[m.id];$('#dm').hidden=!(pd&&my);if(pd&&my){$('#dmb').innerHTML=`<h2 style="margin:0;color:var(--ac)">📋 Decisión de Estado</h2><p>${esc(pd.tx)}</p>`+pd.opts.map((o,i)=>`<button data-i="${i}" style="display:block;width:100%;text-align:left">${esc(o.t)}</button>`).join('');document.querySelectorAll('#dmb [data-i]').forEach(b=>b.onclick=()=>net.emit('act',{type:'ch',i:+b.dataset.i}))}}
document.querySelectorAll('#tabs2 button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#tabs2 button').forEach(z=>z.classList.toggle('on',z==b));document.querySelectorAll('.tp').forEach(p=>p.hidden=p.id!=b.dataset.p)});
let mi=0;const SC={calm:[[220,277,330],[196,247,294],[174,220,262],[196,247,294]],war:[[110,131,165],[116,139,175],[104,123,156],[98,117,147]]};
setInterval(()=>{if(mute||typeof S=='undefined')return;const m0=S&&S.n&&S.n.find(n=>n.peer==me),w=m0&&m0.war.length>0,ch=SC[w?'war':'calm'][mi++%4];ch.forEach((f,i)=>tone(f,w?1.1:2.6,w?'sawtooth':'sine',w?.022:.03,w?0:i*.12));if(w){tone(55,.25,'square',.05);setTimeout(()=>tone(ch[0]*2,.2,'square',.02),1200)}},2400);
document.addEventListener('click',()=>{try{AC&&AC.resume()}catch(e){}});
const wk=(a,b)=>a<b?a+'-'+b:b+'-'+a;
function endWar(a,b){unlink(a,b,'war');delete S.wf[wk(a.id,b.id)]}
function conquer(a,b){const {W,own}=S,bc=cnt(b.id),bord=[];own.forEach((o,i)=>{if(o==b.id){const x=i%W,y=i/W|0;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>x+dx>=0&&x+dx<W&&own[(y+dy)*W+x+dx]==a.id))bord.push(i)}});
 const k=Math.min(bord.length,Math.max(1,Math.ceil(bc*.1)));if(!k)return;const f=k/bc;bord.sort(()=>Math.random()-.5).slice(0,k).forEach(i=>{own[i]=a.id;const ci=b.cities.indexOf(i);if(ci>=0){b.cities.splice(ci,1);a.cities.push(i);a.cap++;L(`🏙 ${a.name} captura una ciudad de ${b.name} en el frente.`,'conq','war')}});a.gdp+=b.gdp*f*.4;a.pop+=b.pop*f;b.gdp*=1-f;b.pop*=1-f;b.stab=Math.max(1,b.stab-8);
 L(`💥 ${a.name} rompe el frente y toma ${k} regiones de ${b.name}.`,'war');
 if(cnt(b.id)==0){b.alive=false;['ally','trade','war','pact','treaty'].forEach(r=>S.n.forEach(x=>x[r]=x[r].filter(i=>i!=b.id)));L(`☠ ${b.name} ha sido eliminada.`,'war')}}
function warRound(){for(const k in S.wf){const w=S.wf[k],A=S.n[w.A],B=S.n[w.B];if(!A.alive||!B.alive||!rel(A,B,'war')){delete S.wf[k];continue}
 if(!nb(A.id).has(B.id)){L(`Guerra ${A.name} vs ${B.name}: sin frente directo, solo bloqueos y escaramuzas.`,'','war');A.stab=Math.max(1,A.stab-1);B.stab=Math.max(1,B.stab-1);continue}
 const M={atk:[1.25,.85],bal:[1,1],def:[.8,1.3]},st=n=>w.o[n.id]||(n.h?'bal':pick(['atk','bal','def'])),sa=st(A),sb=st(B),al=(n,o)=>1+.15*n.ally.filter(i=>S.n[i].alive&&S.n[i].war.includes(o.id)).length,
 pa=pw(A)*M[sa][0]/M[sb][1]*R(.7,1.3)*al(A,B),pb=pw(B)*M[sb][0]/M[sa][1]*R(.7,1.3)*al(B,A),sh=(pa-pb)/(pa+pb)*35;w.fr=Math.max(-60,Math.min(60,w.fr*.6+sh));
 A.mil*=1-(sa=='atk'?.06:sa=='def'?.02:.04)*R(.5,1.5);B.mil*=1-(sb=='atk'?.06:sb=='def'?.02:.04)*R(.5,1.5);A.pop*=.996;B.pop*=.996;A.stab=Math.max(1,A.stab-1.5);B.stab=Math.max(1,B.stab-1.5);
 L(`🪖 Frente ${A.name} vs ${B.name}: ${Math.abs(sh)<5?'combates sin avances claros':sh>0?A.name+' gana terreno':B.name+' gana terreno'} (frente ${Math.round(w.fr)}).`,'','war');
 if(w.fr>=45){conquer(A,B);w.fr=15}else if(w.fr<=-45){conquer(B,A);w.fr=-15}}}
function decide(a,d){const txt=String(d.text||'').slice(0,140),fx=d.fx||{},cl=(v,lo,hi)=>Math.max(lo,Math.min(hi,+v||0)),cost=Math.max(cl(d.cost,0,12),Math.min(12,Math.max(0,+fx.mil||0)*.35+Math.max(0,+fx.gdp||0)*50+['res','tech','pres','dem','stab'].reduce((t,k)=>t+Math.max(0,+fx[k]||0),0)*.25))/100,roll=RI(1,100)-(S.df>1?8:0),ch=[];let mul,res;
 if(roll<=18){mul=-.7;res='❌ FRACASO: la operación sale mal y empeora la situación.'}else if(roll<=55){mul=.5;res='⚠ ÉXITO PARCIAL: resultados modestos.'}else if(roll<=93){mul=1;res='✅ ÉXITO: se logra lo previsto.'}else{mul=1.3;res='🌟 ÉXITO ROTUNDO: por encima de lo esperado.'}
 const rf={gdp:[-.2,.1],pop:[-.08,.03]},ri={mil:[-12,19],stab:[-10,12],res:[-10,12],tech:[-10,12],pres:[-10,12],dem:[-10,12]};a.gdp*=1-cost;ch.push(`coste ${(cost*100).toFixed(0)}% PIB`);
 for(const k in rf){const v0=+fx[k]||0,v=cl(v0>0?v0*mul:v0,rf[k][0],rf[k][1]);if(v){a[k]*=1+v;ch.push(`${LB[k]} ${v>0?'+':''}${(v*100).toFixed(1)}%`)}}
 for(const k in ri){const v0=+fx[k]||0,v=Math.round(cl(v0>0?v0*mul:v0,ri[k][0],ri[k][1]));if(v){a[k]=Math.max(1,Math.min(k=='mil'?200:100,a[k]+v));ch.push(`${LB[k]} ${v>0?'+':''}${v}`)}}
 if(Math.random()<.08*(1+(S.df>1?1:0))){a.stab=Math.max(1,a.stab-6);ch.push('imprevisto: protestas, stab −6')}
 L(`🧠 ${a.name} ordena: «${txt}»`,'','cns');L(`🧠 ${a.name}: ${d.nar?String(d.nar).slice(0,220)+' ':''}${res} (${ch.join(', ')})`,'click','cns');return true}
async function consult(){const t=$('#ci').value.trim(),m=S&&S.n.find(n=>n.peer==me);if(!t||!m||S.t!=m.id||S.win)return;$('#ci').value='';$('#cs').disabled=true;$('#cs').textContent='Consultando…';let fx=null,nar='',cost=3;
 try{const sm=await claude.use('sample');if(sm){const r=await sm.json(`Eres el consejero realista de un juego de estrategia. Nación: ${JSON.stringify({pib_GBP:m.gdp,poblacion:m.pop,militar:m.mil,democracia:m.dem,gobierno:m.gov,estabilidad:m.stab,recursos:m.res,tecnologia:m.tech,prestigio:m.pres,ronda:S.r})}. El líder ordena: "${t}". Devuelve SOLO JSON: {"narrativa":"2 frases realistas con riesgos","costo_pct_pib":0-15,"efectos":{"gdp":fraccion,"pop":fraccion,"mil":puntos,"stab":puntos,"res":puntos,"tech":puntos,"pres":puntos,"dem":puntos}}. Las órdenes pueden SUBIR stats pagando un coste: fabricar armas => costo 3-8% del PIB y mil +5 a +19 puntos; invertir en economía => gdp +1% a +8%; explorar recursos => res +3 a +12; universidades => tech +3 a +12; etc. gdp entre -0.15 y 0.1, pop entre -0.08 y 0.03, mil entero entre -10 y 19, el resto entero entre -10 y 12. Sé realista, nada milagroso; los efectos secundarios negativos son posibles.`);fx=r.efectos;nar=r.narrativa;cost=r.costo_pct_pib}}catch(e){}
 if(!fx){const k=t.toLowerCase();fx=/arma|ejerc|milit|recluta|tanque/.test(k)?{mil:RI(5,14),gdp:-.01}:/recurso|petr|miner|explor|litio/.test(k)?{res:RI(3,9),gdp:.02}:/econom|comerc|invers|impuest/.test(k)?{gdp:.04,stab:-1}:/tecnolog|investig|univers/.test(k)?{tech:RI(3,9)}:/propag|diplom|prestig/.test(k)?{pres:RI(3,9)}:{stab:2};nar='(Modo sin IA) Los consejeros ejecutan la orden con medios limitados.'}
 net.emit('act',{type:'dec',text:t,fx,nar,cost});$('#cs').disabled=false;$('#cs').textContent='Consultar'}
function renderChat(m){if(m)$('#cl').innerHTML=S.log.filter(e=>e.t=='cns'&&e.s.includes(m.name)).slice(0,6).reverse().map(e=>`<div class="lg cns">${esc(e.s)}</div>`).join('')||'<i style="color:var(--mu)">Describe qué quieres hacer: invertir, explorar recursos, reformar, reclutar…</i>'}
function renderWar(m){if(!m)return;const ws=Object.values(S.wf||{}).filter(w=>w.A==m.id||w.B==m.id);$('#wr').innerHTML=ws.length?ws.map(w=>{const e=S.n[w.A==m.id?w.B:w.A],fr=w.A==m.id?w.fr:-w.fr,st=w.o[m.id]||'bal',my=S.t==m.id&&!S.win;return `<div class="lg war"><b>vs ${esc(e.name)}</b> · frente ${fr>0?'+':''}${Math.round(fr)}<div style="height:8px;background:#7f1d1d;border-radius:4px"><div style="height:8px;width:${50+fr*.83}%;background:#22c55e;border-radius:4px"></div></div>Ejércitos: ${Math.round(pw(m))} vs ${Math.round(pw(e))} · Estrategia: <b>${st=='atk'?'Ofensiva':st=='def'?'Defensiva':'Equilibrada'}</b><br>${['atk','bal','def'].map(x=>`<button class="s" data-o="${x}" data-e="${e.id}" ${my&&st!=x?'':'disabled'}>${x=='atk'?'🗡 Ofensiva':x=='def'?'🛡 Defensiva':'⚖ Equilibrada'}</button>`).join('')}<button class="s" data-pz="${e.id}" ${my?'':'disabled'}>🕊 Pedir tregua</button>${S.log.filter(x=>x.t=='war'&&x.s.includes(e.name)&&x.s.includes(m.name)).slice(0,2).map(x=>'<div style="font-size:12px;color:var(--mu)">'+esc(x.s)+'</div>').join('')}</div>`}).join(''):'<i style="color:var(--mu)">No estás en guerra.</i>';
 document.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>net.emit('act',{type:'ord',t:+b.dataset.e,v:b.dataset.o}));document.querySelectorAll('[data-pz]').forEach(b=>b.onclick=()=>net.emit('act',{type:'peace',t:+b.dataset.pz}))}
$('#mf').onchange=e=>{MF=e.target.value;renderGame()};$('#cs').onclick=consult;$('#ci').onkeydown=e=>{if(e.key=='Enter')consult()};

/* ---------- mejoras: multijugador, banderas, chat ---------- */
let CF='',curLive=new Set,gone={},unread=0,lastChat=0;
const cfgTxt=()=>['cMap','cAI','cTm','cEp','cDf','cRd'].map(i=>{const e=$('#'+i);return e.selectedOptions[0].text}).join(' · ');
function chatIn(m){const p=players.find(x=>x.peer==m.peer),L=$('#chL');if(!L)return;const d=document.createElement('div');d.innerHTML='<b style="color:var(--ac)">'+esc(p?p.name:'?')+':</b> '+esc(String(m.data.t||'').slice(0,140));L.appendChild(d);while(L.children.length>80)L.firstChild.remove();L.scrollTop=1e9;if($('#chP').hidden&&!m.isMe){unread++;$('#chB').textContent=unread;$('#chB').hidden=false;snd('notif')}}
$('#chT').onclick=()=>{$('#chP').hidden=!$('#chP').hidden;unread=0;$('#chB').hidden=true;if(!$('#chP').hidden)$('#chI').focus()};
$('#chI').onkeydown=e=>{if(e.key!='Enter')return;const t=e.target.value.trim(),n=Date.now();if(!t||!net||n-lastChat<600)return;lastChat=n;e.target.value='';net.emit('chat',{t:t.slice(0,140)})};
$('#bCopy').onclick=async()=>{try{await navigator.clipboard.writeText(code);$('#bCopy').textContent='✔ Copiado'}catch(e){$('#bCopy').textContent='Código: '+code}};
function watchPeers(ps){curLive=new Set(ps.map(p=>p.peer));if(!host||!S||S.win||isSolo||!curLive.has(me))return;S.n.forEach(n=>{if(!n.h||!n.peer||n.peer==me)return;if(!curLive.has(n.peer)){if(!gone[n.peer])gone[n.peer]=setTimeout(()=>dropP(n.id),7000)}else if(gone[n.peer]){clearTimeout(gone[n.peer]);delete gone[n.peer]}})}
function dropP(id){const n=S&&S.n[id];if(!n||!n.h||curLive.has(n.peer)||S.win)return;n.h=false;n.wasH=true;n.pers=n.pers||pick(PERS);const was=S.t==id;L(`🔌 ${n.name} se desconectó: la IA toma el mando.`,'bad','sys');if(was)endTurn();chk();net.emit('state',S)}
const FL={};function flag(n){if(FL[n.id])return FL[n.id];const c=document.createElement('canvas');c.width=44;c.height=28;const x=c.getContext('2d'),k=n.col,t=n.id%5;x.fillStyle=k;x.fillRect(0,0,44,28);x.fillStyle='#f4f1e8';
 if(t==0){x.fillRect(0,9,44,10)}else if(t==1){x.fillRect(15,0,8,28);x.fillRect(0,10,44,8)}else if(t==2){x.fillStyle='#f5b942';x.beginPath();x.moveTo(0,0);x.lineTo(24,14);x.lineTo(0,28);x.fill()}else if(t==3){x.beginPath();x.arc(22,14,9,0,7);x.fill();x.fillStyle=k;x.beginPath();x.arc(22,14,4,0,7);x.fill()}else{x.fillRect(15,0,14,28);x.fillStyle='#1b2438';x.fillRect(30,0,14,28)}
 x.strokeStyle='#0008';x.strokeRect(.5,.5,43,27);return FL[n.id]=c.toDataURL()}
const _rg=renderGame;renderGame=function(){_rg();try{const m=S.n.find(n=>n.peer==me),cur=S.n[S.t];document.title=(m&&cur&&cur.peer==me&&!S.win)?'🔔 ¡Tu turno! · Nations of Power':'Nations of Power';document.querySelectorAll('#nt tr').forEach((r,i)=>{const n=S.n[i-1],td=r.firstElementChild;if(n&&td&&!td.querySelector('.fl'))td.innerHTML=td.innerHTML.replace(/<span[^>]*>■<\/span>/,'<img class="fl" src="'+flag(n)+'">')})}catch(e){}};

/* ---------- PWA ---------- */
(function(){const ic=n=>{const c=document.createElement('canvas');c.width=c.height=n;const x=c.getContext('2d'),g=x.createRadialGradient(n*.5,n*.4,n*.05,n/2,n/2,n*.7);g.addColorStop(0,'#1c2a4d');g.addColorStop(1,'#0b1220');x.fillStyle=g;x.fillRect(0,0,n,n);x.strokeStyle='#f5b942';x.lineWidth=n*.035;x.beginPath();x.arc(n/2,n*.45,n*.32,0,7);x.stroke();x.beginPath();x.ellipse(n/2,n*.45,n*.13,n*.32,0,0,7);x.stroke();x.beginPath();x.moveTo(n*.18,n*.45);x.lineTo(n*.82,n*.45);x.stroke();x.fillStyle='#f5b942';x.font='bold '+n*.17+'px Georgia';x.textAlign='center';x.fillText('NATIONS',n/2,n*.92);return c.toDataURL()};
 if(!document.querySelector('link[rel=manifest]')){const m={name:'Nations of Power',short_name:'Nations',description:'Estrategia por turnos: diplomacia, economía y guerra',start_url:location.href.split('#')[0],display:'standalone',background_color:'#0b1220',theme_color:'#0b1220',icons:[{src:ic(192),sizes:'192x192',type:'image/png'},{src:ic(512),sizes:'512x512',type:'image/png'}]};const l=document.createElement('link');l.rel='manifest';l.href=URL.createObjectURL(new Blob([JSON.stringify(m)],{type:'application/manifest+json'}));document.head.appendChild(l);const a=document.createElement('link');a.rel='apple-touch-icon';a.href=ic(180);document.head.appendChild(a)}
 let dp;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();dp=e;$('#bInst').hidden=false});$('#bInst').onclick=async()=>{if(dp){dp.prompt();await dp.userChoice;dp=null;$('#bInst').hidden=true}};window.addEventListener('appinstalled',()=>{$('#bInst').hidden=true});
 if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&document.querySelector('link[rel=manifest][href="manifest.webmanifest"]'))navigator.serviceWorker.register('sw.js').catch(()=>{})})();
/* ---------- online: expulsar y reconexión ---------- */
const _rl=rLobby;rLobby=function(){_rl();if(!$('#pl'))return;document.querySelectorAll('#pl .pr').forEach((r,i)=>{const p=players[i];if(host&&p&&p.peer!=me&&!started){const b=document.createElement('button');b.className='s';b.textContent='✖';b.title='Expulsar';b.style.cssText='padding:2px 8px;font-size:11px';b.onclick=()=>net.emit('kick',{peer:p.peer});r.appendChild(b)}})};
let TC=null,MF='pol';const K=18;
function terrain(s){if(TC&&TC.seed==s.seed&&TC.W==s.W)return TC;const W=s.W,H=s.H,PW=W*K,PH=H*K,sd=s.seed,N=PW*PH,el=new Float32Array(N),mk=new Float32Array(N),pc=new Int32Array(N).fill(-1),base=new Uint8ClampedArray(N*4),bio=new Uint8Array(N),Lm=(x,y)=>x<0||y<0||x>=W||y>=H?0:(s.own[y*W+x]>=0?1:0);
 for(let py=0,i=0;py<PH;py++)for(let px=0;px<PW;px++,i++){const gx=px/K-.5,gy=py/K-.5,wx=gx+(vn(gx*.9,gy*.9,sd+5)-.5)*1.5,wy=gy+(vn(gx*.9+7,gy*.9+3,sd+6)-.5)*1.5,x0=Math.floor(wx),y0=Math.floor(wy),fx=wx-x0,fy=wy-y0,a=Lm(x0,y0),b=Lm(x0+1,y0),c=Lm(x0,y0+1),d=Lm(x0+1,y0+1),m=a*(1-fx)*(1-fy)+b*fx*(1-fy)+c*(1-fx)*fy+d*fx*fy;mk[i]=m;
  if(m>=.5){let bw=-1;[[a,x0,y0,(1-fx)*(1-fy)],[b,x0+1,y0,fx*(1-fy)],[c,x0,y0+1,(1-fx)*fy],[d,x0+1,y0+1,fx*fy]].forEach(q=>{if(q[0]&&q[3]>bw){bw=q[3];pc[i]=q[2]*W+q[1]}})}
  el[i]=fbm(gx*.28,gy*.28,sd+1,4)}
 for(let py=0,i=0;py<PH;py++)for(let px=0;px<PW;px++,i++){const p=i*4,m=mk[i],g=(hs(px,py,sd)-.5)*6;let r,gg,bl;
  if(pc[i]<0){const t=Math.min(1,m*2.3),w=Math.sin((px*.8+py*.45)*.35+vn(px*.02,py*.02,sd+3)*12)*.5+.5;r=10+50*t+w*6*t;gg=35+105*t+w*8*t;bl=80+105*t+w*6*t;if(m>.4){const f=(m-.4)*400;r+=f;gg+=f;bl+=f}}
  else{const k=Math.min(1,(m-.5)*3),e=el[i]*(.45+.55*k),mo=vn(px*.012,py*.012,sd+2)*.6+vn(px*.04,py*.04,sd+4)*.4,sh=px>1&&py>1&&px<PW-2&&py<PH-2?(el[i-PW-1]-el[i+PW+1])*500:0;
   if(m<.58){r=226;gg=214;bl=160}else if(e>.66){r=236;gg=240;bl=245}else if(e>.6){r=130;gg=120;bl=112}else if(e>.55){r=118;gg=104;bl=84}else if(mo<.36){r=212;gg=190;bl=118}else if(mo<.45){r=176;gg=178;bl=98}else if(mo<.58){r=88;gg=150;bl=68}else{r=40;gg=104;bl=52}
   bio[i]=e>.6?1:(e<.55&&mo>=.58&&m>.62?2:0);const q=sh+g;r+=q;gg+=q;bl+=q}
  base[p]=r;base[p+1]=gg;base[p+2]=bl;base[p+3]=255}
 const dc=[];for(let py=8;py<PH-8;py+=11)for(let px=8;px<PW-8;px+=11){const jx=px+(hs(px,py,sd+9)-.5)*8|0,jy=py+(hs(px,py,sd+8)-.5)*8|0,b=bio[jy*PW+jx];if(b&&hs(px,py,sd+7)<(b==1?.5:.45))dc.push([jx,jy,b])}
 return TC={seed:sd,W,PW,PH,pc,base,dc}}
function drawMap(m){const T=terrain(S),c=$('#map'),W=S.W,N=S.n.length,PW=T.PW,PH=T.PH;if(c.width!=PW){c.width=PW;c.height=PH}
 const x=c.getContext('2d'),img=x.createImageData(PW,PH),d=img.data,b=T.base,pc=T.pc,own=S.own,rg=S.n.map(n=>hsl(n.col)),rl=new Uint8Array(N*N),O=i=>pc[i]<0?-2:own[pc[i]];
 S.n.forEach(a=>{a.ally.forEach(i=>rl[a.id*N+i]=1);a.war.forEach(i=>rl[a.id*N+i]=2)});
 const sig=own.join(',')+'|'+rl.join('')+'|'+PW;if(drawMap.c&&drawMap.k==sig&&drawMap.c.width==PW){x.drawImage(drawMap.c,0,0)}else{
 for(let py=0,i=0;py<PH;py++)for(let px=0;px<PW;px++,i++){const p=i*4,o=O(i);d[p+3]=255;
  if(o==-2){d[p]=b[p];d[p+1]=b[p+1];d[p+2]=b[p+2];continue}
  const k0=rg[o],pt=o%3==0?Math.sin((px+py)*.5)*3:o%3==1?Math.sin(px*.4)*Math.sin(py*.4)*3:(vn(px*.08,py*.08,o)-.5)*8;
  d[p]=b[p]*.62+k0[0]*.38+pt;d[p+1]=b[p+1]*.62+k0[1]*.38+pt;d[p+2]=b[p+2]*.62+k0[2]*.38+pt;
  for(const q of [px>0?O(i-1):-2,px<PW-1?O(i+1):-2,py>0?O(i-PW):-2,py<PH-1?O(i+PW):-2])if(q!=o){const k=q==-2?0:rl[o*N+q]+1,col=k==0?[40,50,30]:k==1?[15,15,15]:k==2?[40,230,90]:[240,40,40],al=k==0?.5:.65;d[p]=d[p]*(1-al)+col[0]*al;d[p+1]=d[p+1]*(1-al)+col[1]*al;d[p+2]=d[p+2]*(1-al)+col[2]*al;break}}
 x.putImageData(img,0,0);x.filter='blur(0.7px)';x.drawImage(c,0,0);x.filter='none';const oc=drawMap.c||(drawMap.c=document.createElement('canvas'));oc.width=PW;oc.height=PH;oc.getContext('2d').drawImage(c,0,0);drawMap.k=sig}
 if(MF!='pol'){const al=S.n.filter(q=>q.alive),V=q=>MF=='mil'?pw(q):MF=='eco'?q.gdp:MF=='pop'?q.pop:MF=='res'?q.res:MF=='stab'?q.stab:q.inf,mx=Math.max(1e-9,...al.map(V));own.forEach((o,i)=>{if(o<0)return;const q=S.n[o];let col;if(MF=='dip'){col=!m?'#888':q.id==m.id?'#f5b942':m.war.includes(q.id)?'#e5484d':m.ally.includes(q.id)?'#3fb97a':m.trade.includes(q.id)?'#38bdf8':'#6b7280'}else col=`hsl(${Math.round(210-Math.pow(V(q)/mx,.6)*210)},85%,50%)`;x.globalAlpha=.55;x.fillStyle=col;x.fillRect((i%W)*K,(i/W|0)*K,K,K)});x.globalAlpha=1}
 T.dc.forEach(([px,py,b])=>{const o=own[pc[py*PW+px]];if(o==undefined||o<0)return;if(b==1){x.fillStyle='rgba(60,50,45,.75)';x.beginPath();x.moveTo(px-5,py+3);x.lineTo(px,py-5);x.lineTo(px+5,py+3);x.fill();x.fillStyle='rgba(255,255,255,.85)';x.beginPath();x.moveTo(px-1.8,py-2);x.lineTo(px,py-5);x.lineTo(px+1.8,py-2);x.fill()}else{x.fillStyle='rgba(20,70,30,.85)';x.beginPath();x.arc(px,py-1,3.5,0,7);x.fill();x.fillStyle='rgba(60,40,20,.9)';x.fillRect(px-.5,py+1,1.5,3)}});const sm={};own.forEach((o,i)=>{if(o<0)return;const s=sm[o]=sm[o]||[0,0,0];s[0]+=i%W;s[1]+=i/W|0;s[2]++});x.textAlign='center';const cur=S.n[S.t],CAP=window.__CAP={};
 Object.keys(sm).forEach(o=>{const s=sm[o],n=S.n[o],cx=s[0]/s[2],cy=s[1]/s[2];let best=1e9,bx=0,by=0;own.forEach((q,i)=>{if(q==o){const dd=Math.hypot(i%W-cx,(i/W|0)-cy);if(dd<best){best=dd;bx=i%W;by=i/W|0}}});
  const X=(bx+.5)*K,Y=(by+.5)*K;CAP[o]=[X,Y];const mine=m&&m.id==n.id,tn=n.name.replace('Imperio de ','');
  x.fillStyle='#222';x.fillRect(X-6,Y-4,12,9);x.fillStyle=mine?'#ffd25a':'#f2e9d0';x.fillRect(X-5,Y-3,10,7);x.fillRect(X-5,Y-6,3,3);x.fillRect(X-1.5,Y-6,3,3);x.fillRect(X+2,Y-6,3,3);
  if(cur&&cur.id==n.id){x.strokeStyle='#ffd25a';x.lineWidth=2;x.beginPath();x.arc(X,Y,13,0,7);x.stroke()}
  x.lineWidth=3;x.strokeStyle='rgba(0,0,0,.75)';x.font=(mine?'bold ':'')+'12px Georgia,serif';x.fillStyle='#fff';x.strokeText(tn,X,Y+19);x.fillText(tn,X,Y+19);
  x.font='600 10px sans-serif';x.fillStyle='#efd08a';x.strokeText(Math.round(pw(n)),X,Y+30);x.fillText(Math.round(pw(n)),X,Y+30)});
 Object.values(S.wf||{}).forEach(w=>{const p=CAP[w.A],q=CAP[w.B];if(!p||!q)return;x.setLineDash([6,5]);x.strokeStyle='rgba(255,60,60,.85)';x.lineWidth=2;x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(q[0],q[1]);x.stroke();x.setLineDash([]);(window.__ico&&__ico(x,'⚔',(p[0]+q[0])/2,(p[1]+q[1])/2,20,'#f6dede','#ff8a8a'))||(x.font='18px serif',x.fillText('⚔',(p[0]+q[0])/2,(p[1]+q[1])/2+6))});
 if(selC!=null){x.strokeStyle='#fff';x.lineWidth=3;x.strokeRect((selC%W)*K,(selC/W|0)*K,K,K)}
 (S.ev||[]).forEach(e=>{(window.__ico&&__ico(x,e.i,(e.c%W+.5)*K,((e.c/W|0)+.5)*K,26))||(x.font='24px serif',x.fillText(e.i,(e.c%W+.5)*K,((e.c/W|0)+.5)*K))});
 const g=x.createRadialGradient(PW/2,PH/2,PH*.4,PW/2,PH/2,PW*.65);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.45)');x.fillStyle=g;x.fillRect(0,0,PW,PH);
 x.strokeStyle=x.fillStyle='rgba(245,230,176,.8)';x.lineWidth=1.2;x.font='600 12px Georgia';x.beginPath();x.moveTo(PW-40,PH-20);x.lineTo(PW-40,PH-60);x.moveTo(PW-60,PH-40);x.lineTo(PW-20,PH-40);x.stroke();x.fillText('N',PW-40,PH-66)}
$('#map').onclick=e=>{if(!S||!TC)return;const c=e.target,r=c.getBoundingClientRect(),px=Math.floor((e.clientX-r.left)*c.width/r.width),py=Math.floor((e.clientY-r.top)*c.height/r.height),k=TC.pc[py*TC.PW+px];if(k>=0){selT=S.own[k];selC=k;renderGame()}};
setInterval(()=>{if(!S||S.win)return;const r=S.tm?Math.max(0,(S.dl-Date.now())/1000):0,t=$('#tt');if(t)t.textContent=S.tm?Math.ceil(r)+'s':'∞';$('#tm').style.width=S.tm?Math.min(100,r/S.tm*100)+'%':'0';if(host&&S.tm&&Date.now()>S.dl){endTurn();net.emit('state',S)}},1000);
document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#tabs button').forEach(z=>z.classList.toggle('on',z==b));['p','h','a'].forEach(t=>$('#t'+t).hidden=t!=b.dataset.t)});
(function(){const W=40,H=25,seed=RI(1,9999),own=Array(W*H).fill(-1);lands(W,H,seed).forEach(i=>own[i]=0);const T=terrain({W,H,seed,own}),c=$('#bg');c.width=T.PW;c.height=T.PH;c.getContext('2d').putImageData(new ImageData(T.base,T.PW,T.PH),0,0)})();
document.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{if(b.dataset.a=='war'&&!b.dataset.cf){b.dataset.cf=1;b._t=b.textContent;b.textContent='⚠ ¿Seguro? Pulsa de nuevo';setTimeout(()=>{delete b.dataset.cf;b.textContent=b._t},3000);return}if(b._t){delete b.dataset.cf;b.textContent=b._t}net.emit('act',{type:b.dataset.a,t:Number($('#tg').value),c:selC})});
$('#bEnd').onclick=()=>net.emit('endt',{});

/*POLISH*/
/* ===== Set de iconos unificado: trazo fino + detalle dorado ===== */
const NOPI={
swords:['<path d="M3.5 3.500 15 15M20.500 3.500 9 15M15 15l4.500 4.500M9 15l-4.500 4.500"/>','<path d="M13 17l4-4M11 17l-4-4"/><circle cx="19.5" cy="19.5" r="1" fill="#000"/><circle cx="4.5" cy="19.5" r="1" fill="#000"/>'],
dagger:['<path d="M12 2.8 14.3 12H9.7Z"/><path d="M12 12v6"/>','<path d="M8 12h8"/><circle cx="12" cy="20" r="1.5"/>'],
helmet:['<path d="M5 14.500a7 7 0 0 1 14 0V20h-3.500v-4H8.500v4H5z"/>','<path d="M8.500 5.500c2.200-1.700 4.800-1.700 7 0M12 9.500v6"/>'],
shield:['<path d="M12 3 19.5 6v6c0 4.5-3.5 7.5-7.5 9-4-1.5-7.5-4.5-7.5-9V6Z"/>','<path d="M12 7.5v9M8.2 11.8h7.6"/>'],
handshake:['<path d="M2.5 9H6l3.5-1.5H13L16 9.5l5.5-.5"/><path d="M2.5 9v5H6l5.5 4.5c1 .8 2.4.5 3-.5l6-4V9"/>','<path d="M9 12.5l3 2.5M11.5 11l2.8 2.5"/>'],
microscope:['<path d="M9 3.5l4 2-2.5 5-4-2Z"/><path d="M12.5 8.5c4 .5 6 3.5 5.5 7-.4 2.5-3 4-6 4"/><path d="M6 21h12"/>','<path d="M5.5 17h6"/><path d="M7.4 11.7l1.3.7"/>'],
clipboard:['<path d="M7.5 5.5h-2v15h13v-15h-2"/><path d="M8.5 12h7M8.5 15.5H13"/>','<path d="M9 3.5h6v4H9z"/>'],
columns:['<path d="M3 9l9-5 9 5z"/><path d="M6 11.5v5.5M10 11.5v5.5M14 11.5v5.5M18 11.5v5.5"/>','<path d="M3.5 20.5h17M5 18h14"/>'],
scroll:['<path d="M6 5a2 2 0 0 1 2-2h11v12.5H8a2 2 0 0 0-2 2z"/><path d="M6 17.5A2.5 2.5 0 0 0 8.5 20h9.5a2 2 0 0 0 2-2v-2.5"/>','<path d="M10 7h6M10 10.5h6"/>'],
skull:['<path d="M12 3.5c-4.5 0-7 3-7 6.5 0 2.500 1.300 4 2.500 5v3.500h9V15c1.200-1 2.500-2.500 2.500-5 0-3.500-2.500-6.500-7-6.500z"/>','<circle cx="9.3" cy="10.5" r="1.4" fill="#000"/><circle cx="14.7" cy="10.5" r="1.4" fill="#000"/><path d="M10.5 18.500V16M13.500 18.500V16"/>'],
exchange:['<path d="M4 8.5h15M20 15.5H5"/>','<path d="M16 5.500l3 3-3 3M8 12.500l-3 3 3 3"/>'],
dove:['<path d="M3 12.500c3-2 5-1.500 7-.5 0-3.500 2.500-6.500 6-7-.5 2 0 3 1 3.500 2 0 3.500-1 4.500-1.500-.5 2.500-2 4.500-4 5 -.5 3.500-3.500 6.500-8 6-1.500-.2-3-1.200-3.500-2.700z"/>','<circle cx="16.500" cy="7.500" r=".9" fill="#000"/><path d="M21 7.500l1.500.5"/>'],
coin:['<circle cx="12" cy="12" r="8.500"/>','<path d="M9.200 9.700c.8-1.300 4.300-1.500 5.400 0M9.200 14.300c.8 1.300 4.600 1.500 5.600 0M12 7.500v9"/>'],
scales:['<path d="M12 4v16M7 20h10M5 7.500h14"/>','<path d="M5 7.500l-2.200 6h4.400zM19 7.500l-2.200 6h4.400z"/>'],
user:['<circle cx="12" cy="8" r="3.500"/><path d="M5 20c0-4 3-6 7-6s7 2 7 6"/>','<path d="M9.500 18.500h5"/>'],
map:['<path d="M3.500 6.500 9 4.500l6 2 5.500-2v13l-5.500 2-6-2-5.500 2z"/>','<path d="M9 4.500v13M15 6.500v13"/>'],
rocket:['<path d="M12 2.800c3.500 2.700 4.500 6.700 4 11.700H8c-.5-5 .5-9 4-11.700z"/><path d="M8 12l-3 4.500h3M16 12l3 4.500h-3"/>','<path d="M10.500 17.500 12 21.500l1.500-4"/><circle cx="12" cy="9" r="1.600"/>'],
warning:['<path d="M12 3.500 21.500 19.500h-19z"/>','<path d="M12 9.500V14"/><circle cx="12" cy="16.800" r=".9" fill="#000"/>'],
globe:['<circle cx="12" cy="12" r="8.500"/><path d="M3.500 12h17"/>','<path d="M12 3.500c-3 3.500-3 13 0 17M12 3.500c3 3.500 3 13 0 17"/>'],
users:['<circle cx="9" cy="8.500" r="3"/><path d="M3.500 19c0-3.500 2.500-5 5.500-5s5.500 1.500 5.500 5"/>','<circle cx="16.500" cy="9.500" r="2.400"/><path d="M16.500 14c2.500 0 4 1.500 4 4.500"/>'],
pickaxe:['<path d="M4.500 20 14 10.500"/>','<path d="M8 7c3.500-3 8.500-2.500 11.500 1l-2 1c-2-2-5-2.500-7.500-.5z"/>'],
news:['<path d="M5 5h13.500v13.500A1.500 1.500 0 0 1 17 20H6.500A1.500 1.500 0 0 1 5 18.500zM18.500 9H21v9a2 2 0 0 1-2 2"/>','<path d="M8 8.500h6M8 12h7.500M8 15.500h7.500"/>'],
quill:['<path d="M20 4c-6 0-11.500 4-13 11l-2 4 4-2c7-1.500 11-7 11-13z"/>','<path d="M5 20l6-7"/>'],
ban:['<circle cx="12" cy="12" r="8.500"/>','<path d="M6 6l12 12"/>'],
burst:['<path d="M12 2.500 14 8l5.500-2.500-3 5 5 1.500-5 1.500 3 5L14 16l-2 5.500L10 16l-5.500 2.500 3-5-5-1.500 5-1.500-3-5L10 8z"/>','<circle cx="12" cy="12" r="2"/>'],
city:['<path d="M3.500 20.500V11H9v9.500M9 20.500V5.500h6v15M15 20.500V9.500h5.500v11M2.500 20.500h19"/>','<path d="M11 9h2M11 12.500h2M11 16h2M17 13h1.500M17 16.500h1.500"/>'],
play:['<path d="M8 5l11 7-11 7z"/>',''],
skip:['<path d="M5 5.500 14 12l-9 6.500z"/>','<path d="M17.500 5.500v13"/>'],
speaker:['<path d="M4 9.500h4L13 5.500v13L8 14.500H4z"/>','<path d="M16 9c1.500 1.500 1.500 4.500 0 6M18.500 6.500c3 3 3 8 0 11"/>'],
mute:['<path d="M4 9.500h4L13 5.500v13L8 14.500H4z"/>','<path d="M16 9.500l5 5M21 9.500l-5 5"/>'],
gift:['<path d="M4.500 10.500h15V20h-15zM3.500 7.500h17v3h-17z"/>','<path d="M12 7.500V20M12 7.500C10 3.500 6.500 4 7.500 6.500 8 7.500 10 7.500 12 7.500s4 0 4.500-1C17.500 4 14 3.500 12 7.500"/>'],
hands:['<path d="M3 11c0 5 4 8.500 9 8.500s9-3.500 9-8.500M3 11l3-2M21 11l-3-2"/>','<circle cx="12" cy="9" r="2.600"/>'],
fist:['<path d="M7 11V8.500a1.500 1.500 0 0 1 3 0V8a1.500 1.500 0 0 1 3 0v.5a1.500 1.500 0 0 1 3 0v1a1.500 1.500 0 0 1 3 0V14c0 4-2.500 6-6 6h-1.500c-3 0-5-2.500-5-5.500V12z"/>','<path d="M10 12.500h7"/>'],
factory:['<path d="M3.500 20.500v-10L9 14v-3.500L14.500 14V8h6v12.500zM16 8V4h3v4"/>','<path d="M6.500 17h1.500M11 17h1.500M16 17h1.500"/>'],
plug:['<path d="M8 3.500V8M16 3.500V8M6 8h12v4a6 6 0 0 1-12 0z"/>','<path d="M12 18v3.500"/>'],
crown:['<path d="M4 17.500 3.500 8l5 4 3.500-6.500 3.500 6.500 5-4-.5 9.500z"/>','<path d="M4 20.500h16"/><circle cx="3.500" cy="7" r="1" fill="#000"/><circle cx="12" cy="4.500" r="1" fill="#000"/><circle cx="20.500" cy="7" r="1" fill="#000"/>'],
check:['<path d="M5 12.500l5 5 9.500-11"/>',''],
ballot:['<path d="M4.500 11h15v9h-15zM8 11V4.500h8V11"/>','<path d="M9 14.500h6M10 7.800l1.500 1.400 2.500-3"/>'],
virus:['<circle cx="12" cy="12" r="4.500"/>','<path d="M12 3v3.500M12 17.500V21M3 12h3.500M17.500 12H21M5.600 5.600 8 8M16 16l2.400 2.400M18.400 5.600 16 8M8 16l-2.400 2.400"/>'],
mask:['<path d="M4 5.500c4 2 12 2 16 0V12c0 4.500-3.500 8-8 8s-8-3.500-8-8z"/>','<path d="M7.500 10.500q2 1.500 3.500 0M13 10.500q1.500 1.500 3.500 0M9 15q3 2 6 0"/>'],
gear:['<path d="M12 2.500 13.600 5 16.400 4.100 17 6.900 19.800 7.600 18.900 10.300 21 12 18.900 13.700 19.800 16.400 17 17.100 16.400 19.900 13.600 19 12 21.500 10.400 19 7.600 19.900 7 17.100 4.200 16.400 5.100 13.700 3 12 5.100 10.300 4.200 7.600 7 6.900 7.600 4.100 10.400 5z"/>','<circle cx="12" cy="12" r="3"/>'],
book:['<path d="M12 6C10 4.500 6.500 4.500 4 5.500v13c2.500-1 6-1 8 .5 2-1.500 5.500-1.500 8-.5v-13C17.500 4.500 14 4.500 12 6z"/>','<path d="M12 6v13"/>'],
install:['<path d="M7 3.500h10v17H7z"/>','<path d="M12 8v6M9.200 11.500l2.800 2.800 2.800-2.800"/>'],
wheel:['<circle cx="12" cy="12" r="8.500"/><path d="M12 3.500v17M3.500 12h17M6 6l12 12M18 6 6 18"/>','<circle cx="12" cy="12" r="2.200" fill="#000"/>'],
trophy:['<path d="M7.500 4h9v6a4.500 4.500 0 0 1-9 0zM7.500 6h-3C4.500 9 5.500 10.500 7.800 11M16.500 6h3c0 3-1 4.500-3.300 5M12 14.500V18"/>','<path d="M8.500 20.500h7M12 18v2.500"/>'],
chat:['<path d="M4.500 5.500h15v10H11L7 19v-3.500H4.500z"/>','<circle cx="8.500" cy="10.500" r=".9" fill="#000"/><circle cx="12" cy="10.500" r=".9" fill="#000"/><circle cx="15.500" cy="10.500" r=".9" fill="#000"/>'],
eye:['<path d="M2.500 12c2.500-4.500 6-6.500 9.500-6.500s7 2 9.500 6.500c-2.500 4.500-6 6.500-9.500 6.500S5 16.500 2.500 12z"/>','<circle cx="12" cy="12" r="3"/>'],
mail:['<path d="M3.500 6h17v12h-17z"/>','<path d="M3.500 6.500 12 13l8.500-6.500"/>'],
dice:['<rect x="5" y="5" width="14" height="14" rx="3"/>','<g fill="#000"><circle cx="9" cy="9" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="9" cy="15" r="1"/><circle cx="15" cy="15" r="1"/></g>'],
calendar:['<rect x="4" y="5.500" width="16" height="14.500" rx="2"/><path d="M8 3.500v4M16 3.500v4"/>','<path d="M4 10.500h16"/><g fill="#000"><circle cx="8.500" cy="14.500" r=".9"/><circle cx="12" cy="14.500" r=".9"/><circle cx="15.500" cy="14.500" r=".9"/></g>'],
timer:['<circle cx="12" cy="13.500" r="7.500"/><path d="M10 3.500h4"/>','<path d="M12 13.500V9.500M12 13.500l2.500-1.500"/>'],
wind:['<path d="M3.500 7H17a2.500 2.500 0 1 0-2.500-2.500M3.500 11.500H20a2.500 2.500 0 1 1-2.500 2.500"/>','<path d="M3.500 16H12a2 2 0 1 1-2 2"/>'],
volcano:['<path d="M3 20.500 9.500 10h5L21 20.500z"/>','<path d="M12 3v4M8.500 5l1.200 2.500M15.500 5l-1.200 2.500"/>'],
wave:['<path d="M2.500 9c2.500-3 4.500-3 6.500 0s4 3 6 0 4.500-3 6.500 0"/>','<path d="M2.500 15c2.500-3 4.500-3 6.500 0s4 3 6 0 4.500-3 6.500 0"/>'],
sun:['<circle cx="12" cy="12" r="4"/>','<path d="M12 2.500V5M12 19v2.500M2.500 12H5M19 12h2.500M5.300 5.300 7 7M17 17l1.700 1.700M18.700 5.300 17 7M7 17l-1.700 1.700"/>'],
flame:['<path d="M12 2.800c1 3.700 6 6.200 6 11.200 0 3.800-2.700 6.500-6 6.500S6 17.800 6 14c0-2.500 1.500-4 2.500-5.500.7 1.500 1.500 2 2.200 2 1-2 .8-5 1.300-7.700z"/>','<path d="M12 20.500c-1.700 0-2.700-1.500-2.500-3.200.2-1.500 1.500-2.300 2.500-3.800 1 1.500 2.500 2.300 2.500 4 0 1.700-1 3-2.500 3z"/>'],
chart:['<path d="M3.500 4v16h17"/>','<path d="M6.500 15 11 10.500l3 3 5.500-6M15.500 7.500h4v4"/>'],
oil:['<path d="M12 3c3.500 5 6 8 6 11.500 0 3.500-2.700 6-6 6s-6-2.500-6-6C6 11 8.500 8 12 3z"/>','<path d="M9.500 15c0 1.500 1 2.500 2.500 2.800"/>'],
megaphone:['<path d="M4 10h4l8.500-4.500v13L8 14H4zM8 14l1 5.500h2.500L10.500 15"/>','<path d="M19 9.500c1.200 1.500 1.200 3.500 0 5"/>'],
barrier:['<path d="M3 8h18v6H3zM6 14v6M18 14v6"/>','<path d="M8 8l-2.500 6M13 8l-2.500 6M18 8l-2.500 6"/>'],
palette:['<path d="M12 3.500c-5 0-8.500 4-8.500 8.500s3.500 8.500 8 8.500c1.700 0 2.300-1.300 1.500-2.500s0-2.500 1.500-2.500h3c2 0 3-1.500 3-3.500 0-4.500-3.500-8.500-8.500-8.500z"/>','<g fill="#000"><circle cx="8" cy="10" r="1.200"/><circle cx="12" cy="7.500" r="1.200"/><circle cx="16" cy="10" r="1.200"/></g>'],
wheat:['<path d="M12 21V8"/>','<path d="M12 12c-2.500-.5-3.700-2-4-4 2 .3 3.600 1.600 4 4M12 12c2.500-.5 3.700-2 4-4-2 .3-3.600 1.600-4 4M12 17c-2.500-.5-3.700-2-4-4 2 .3 3.600 1.600 4 4M12 17c2.500-.5 3.700-2 4-4-2 .3-3.600 1.600-4 4M12 8c-1-1.500-1-3 0-4.500 1 1.500 1 3 0 4.500z"/>'],
laptop:['<path d="M5.500 6h13v9.500h-13zM2.500 18.500h19l-2-3h-15z"/>','<path d="M9 9.500l2 1.500-2 1.500M13 12.500h2.500"/>'],
umbrella:['<path d="M3.500 12C3.500 7 7.500 4 12 4s8.500 3 8.500 8z"/><path d="M12 12v6.500a2 2 0 0 1-4 0"/>','<path d="M8 12c0-2.500 1.800-5 4-8 2.200 3 4 5.500 4 8"/>'],
cap:['<path d="M2.500 9.500 12 5l9.500 4.500L12 14z"/><path d="M6.500 11.500V16c1.500 1.800 9.500 1.800 11 0v-4.500"/>','<path d="M21 10v5"/>'],
thermo:['<path d="M10 14V5.500a2 2 0 0 1 4 0V14a4 4 0 1 1-4 0z"/>','<path d="M12 9v7.500"/><circle cx="12" cy="17" r="1.500" fill="#000"/>'],
star:['<path d="M12 3.500 14.600 9l5.900.7-4.400 4.100 1.200 5.900-5.300-2.900-5.300 2.900 1.200-5.900L3.500 9.700 9.400 9z"/>','<circle cx="12" cy="12" r="1.300" fill="#000"/>'],
cross:['<path d="M6 6l12 12M18 6 6 18"/>',''],
bell:['<path d="M6 17c1-1.500 1.500-3.500 1.500-6 0-3.200 1.800-5.500 4.500-5.500s4.500 2.300 4.500 5.500c0 2.500.5 4.500 1.500 6z"/><path d="M12 3.500v2"/>','<path d="M10 19.500a2 2 0 0 0 4 0"/>'],
info:['<circle cx="12" cy="12" r="8.500"/>','<path d="M12 11v5.500"/><circle cx="12" cy="7.800" r=".9" fill="#000"/>']
};
const NOPE={'⚔':'swords','🗡':'dagger','🪖':'helmet','🛡':'shield','🤝':'handshake','🔬':'microscope','📋':'clipboard','🏛':'columns','🏦':'columns','📜':'scroll','☠':'skull','💱':'exchange','🕊':'dove','💰':'coin','💸':'coin','⚖':'scales','👤':'user','🗺':'map','🚀':'rocket','⚠':'warning','🌐':'globe','🌍':'globe','👥':'users','⛏':'pickaxe','📰':'news','🧠':'quill','🚫':'ban','⛔':'ban','💥':'burst','🏙':'city','▶':'play','🔊':'speaker','🔇':'mute','🎁':'gift','🤲':'hands','😠':'fist','✊':'fist','🏭':'factory','🔌':'plug','👑':'crown','✔':'check','✅':'check','🗳':'ballot','🦠':'virus','🎭':'mask','⚙':'gear','📖':'book','⏯':'play','⏭':'skip','📲':'install','🎰':'wheel','🏆':'trophy','💬':'chat','👁':'eye','🕵':'eye','📨':'mail','🎲':'dice','📅':'calendar','⏱':'timer','🌪':'wind','🌋':'volcano','🌊':'wave','☀':'sun','🔥':'flame','📈':'chart','⛽':'oil','🛢':'oil','📢':'megaphone','🚧':'barrier','🎨':'palette','🌾':'wheat','💻':'laptop','🏖':'umbrella','🎓':'cap','🌡':'thermo','⭐':'star','🌟':'star','❌':'cross','✖':'cross','🔔':'bell','ℹ':'info'};
(function(){
  const svg=(inner,stroke)=>"data:image/svg+xml,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="${stroke}" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`);
  let css='';
  for(const k in NOPI){const[m,g]=NOPI[k];css+=`.ic[data-i="${k}"]{--m:url("${svg(m,'#000')}");--g:url("${svg(g||'<path d="M0 0"/>','#000')}")}\n`}
  const st=document.createElement('style');st.id='nop-icons';st.textContent=css;document.head.appendChild(st);
  window.NOPI=NOPI;window.NOPE=NOPE;
  /* canvas: imágenes a color (trazo crema + detalle dorado) */
  const IMG={};
  function getImg(n,M,G){const k=n+'|'+M+'|'+G;let im=IMG[k];if(!im){im=IMG[k]=new Image();const[a,b]=NOPI[n];
    im.src="data:image/svg+xml,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"><g stroke="${M}">${a}</g><g stroke="${G}">${b.replace(/fill="#000"/g,`fill="${G}"`)}</g></svg>`)}return im}
  window.__ico=function(x,e,cx,cy,sz,main,gold){
    const n=NOPE[(e||'').replace(/\ufe0f/g,'')];if(!n||!NOPI[n])return false;
    const im=getImg(n,main||'#f4ead0',gold||'#e6b755');
    if(!im.complete||!im.naturalWidth)return false;
    x.save();x.shadowColor='rgba(0,0,0,.75)';x.shadowBlur=4;x.drawImage(im,cx-sz/2,cy-sz/2,sz,sz);x.restore();return true};
  Object.keys(NOPI).forEach(n=>getImg(n,'#f4ead0','#e6b755'));
  /* sustitución de emojis en el DOM, conservando el texto para textContent */
  const keys=Object.keys(NOPE).sort((a,b)=>b.length-a.length).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
  const RX=new RegExp('('+keys.join('|')+')[\\ufe0f\\u20e3]?','gu'),TEST=new RegExp(keys.join('|'),'u'),EMO=new RegExp('('+keys.join('|')+')[\\ufe0f]?\\s*','gu');
  const SKIP=/^(OPTION|SCRIPT|STYLE|TEXTAREA|INPUT|CANVAS|TITLE)$/;
  function mk(e){const n=NOPE[e];const s=document.createElement('span');s.className='ic';s.dataset.i=n;s.setAttribute('aria-hidden','true');const t=document.createElement('span');t.className='ie';t.textContent=e;s.appendChild(t);return s}
  function conv(root){
    const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentNode;return(p&&!SKIP.test(p.nodeName)&&!(p.classList&&p.classList.contains('ie'))&&TEST.test(n.nodeValue))?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}}),L=[];let n;while(n=w.nextNode())L.push(n);
    L.forEach(t=>{const s=t.nodeValue,f=document.createDocumentFragment();let last=0,m;RX.lastIndex=0;
      while(m=RX.exec(s)){if(m.index>last)f.appendChild(document.createTextNode(s.slice(last,m.index)));f.appendChild(mk(m[1]));last=m.index+m[0].length;if(s[last]===' ')last++}
      if(last<s.length)f.appendChild(document.createTextNode(s.slice(last)));t.parentNode.replaceChild(f,t)});
    root.querySelectorAll&&root.querySelectorAll('option').forEach(o=>{const v=o.textContent.replace(EMO,'').trim();if(v!==o.textContent)o.textContent=v});
  }
  window.__nopConv=conv;
  let q=new Set(),raf=0;
  const mo=new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData'){const p=m.target.parentNode;p&&p.nodeType===1&&q.add(p)}else m.addedNodes.forEach(n=>{n.nodeType===1?q.add(n):(n.nodeType===3&&n.parentNode&&q.add(n.parentNode))})}
    if(!raf)raf=requestAnimationFrame(()=>{raf=0;const L=[...q];q.clear();mo.disconnect();try{L.forEach(r=>{if(r.isConnected&&!(r.classList&&r.classList.contains('ie')))conv(r)})}finally{mo.takeRecords();mo.observe(document.body,{childList:true,subtree:true,characterData:true})}})});
  conv(document.body);mo.observe(document.body,{childList:true,subtree:true,characterData:true});
})();

/* ===== polish.js · capa de vida y feedback (no altera mecánicas) ===== */
(function(){
const $q=s=>document.querySelector(s),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a);
const RM=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
const ease=t=>1-Math.pow(1-t,3);
function hex(c){c=(c||'#d7a64a').replace('#','');if(c.length==3)c=c.replace(/./g,'$&$&');return[0,2,4].map(i=>parseInt(c.substr(i,2),16)||0)}
function mixc(a,b,t){const A=hex(a),B=hex(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}

/* --- tema: el acento deja de cambiar de color por pantalla; siempre azul + oro (o el color elegido) --- */
applyTheme=function(id){scr=id||scr;const r=document.documentElement.style,c=(typeof thc!=='undefined'&&thc!='auto')?thc:'#d7a64a';
  r.setProperty('--ac',c);r.setProperty('--ac-hi',mixc(c,'#ffffff',.34));r.setProperty('--ac-lo',mixc(c,'#000000',.34));r.setProperty('--bg','#0a1020')};
try{applyTheme()}catch(e){}

/* --- andamiaje DOM --- */
const bn=document.createElement('div');bn.id='banner';bn.innerHTML='<h2></h2><p></p>';document.body.appendChild(bn);
const ts=document.createElement('div');ts.id='toast';document.body.appendChild(ts);
function banner(t,s){const h=bn.querySelector('h2'),p=bn.querySelector('p');h.textContent=t;p.textContent=s||'';bn.classList.remove('show');void bn.offsetWidth;bn.classList.add('show')}
function toast(t,bad){const d=document.createElement('div');if(bad)d.className='bad';d.textContent=t;ts.appendChild(d);if(window.__nopConv)__nopConv(d);setTimeout(()=>d.remove(),3100);while(ts.children.length>3)ts.firstChild.remove()}

/* ============ EFECTOS DEL MAPA (capa canvas superpuesta) ============ */
const FX={Q:RM?0:2,cost:0,err:null,cv:null,x:null,W:0,H:0,seed:null,waves:[],glints:[],ships:[],birds:[],clouds:[],smoke:[],emit:[],flags:[],cities:[],motes:[],hits:[],
  t:0,acc:0,last:0,nextBird:5,fr:0,slow:0,vis:true,pcs:null};
window.__nopfx=FX;
function spr(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);return c}
const SP={
 puffD:spr(48,48,(g,w)=>{const r=g.createRadialGradient(24,24,0,24,24,24);r.addColorStop(0,'rgba(78,84,100,.75)');r.addColorStop(.6,'rgba(78,84,100,.28)');r.addColorStop(1,'rgba(78,84,100,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 puffL:spr(48,48,(g,w)=>{const r=g.createRadialGradient(24,24,0,24,24,24);r.addColorStop(0,'rgba(232,236,244,.7)');r.addColorStop(.6,'rgba(232,236,244,.25)');r.addColorStop(1,'rgba(232,236,244,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 ember:spr(24,24,(g,w)=>{const r=g.createRadialGradient(12,12,0,12,12,12);r.addColorStop(0,'rgba(255,214,150,.95)');r.addColorStop(.35,'rgba(255,110,70,.55)');r.addColorStop(1,'rgba(255,80,50,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 flash:spr(64,64,(g,w)=>{const r=g.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,255,255,.9)');r.addColorStop(.4,'rgba(255,255,255,.3)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 cloud:[0,1,2].map(k=>spr(260,120,(g,w,h)=>{for(let i=0;i<9;i++){const cx=40+Math.random()*(w-80),cy=h*.55+(Math.random()-.5)*28,r=24+Math.random()*30,q=g.createRadialGradient(cx,cy,0,cx,cy,r);q.addColorStop(0,'rgba(255,255,255,.55)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(cx-r,cy-r,r*2,r*2)}}))
};
FX.init=function(){
  if(this.cv)return;const mw=$q('.mw'),map=$q('#map');if(!mw||!map)return;
  const c=document.createElement('canvas');c.id='fx';c.setAttribute('aria-hidden','true');mw.insertBefore(c,map.nextSibling);this.cv=c;this.x=c.getContext('2d');
  if('IntersectionObserver'in window)new IntersectionObserver(e=>{FX.vis=e[0].isIntersecting}).observe(map);
  requestAnimationFrame(ts=>{FX.last=ts;loop(ts)});
};
const wat=(T,x,y)=>x>=0&&y>=0&&x<T.PW&&y<T.PH&&T.pc[(y|0)*T.PW+(x|0)]<0;
const wat9=(T,x,y,r)=>wat(T,x,y)&&wat(T,x+r,y)&&wat(T,x-r,y)&&wat(T,x,y+r)&&wat(T,x,y-r)&&wat(T,x+r*.7,y+r*.7)&&wat(T,x-r*.7,y-r*.7);
function spot(T,r,tries){for(let i=0;i<(tries||600);i++){const x=rnd(r,T.PW-r),y=rnd(r,T.PH-r);if(wat9(T,x,y,r))return[x,y]}return null}
FX.build=function(T){
  this.T=T;this.seed=T.seed+':'+T.PW;this.W=T.PW;this.H=T.PH;this.cv.width=T.PW;this.cv.height=T.PH;
  const q=this.Q,P=this;P.waves=[];P.glints=[];P.ships=[];P.clouds=[];P.motes=[];P.birds=[];
  for(let i=0,n=q>1?80:40;i<n;i++){const p=spot(T,7,80);if(p)P.waves.push({x:p[0],y:p[1],l:rnd(8,17),p:rnd(0,6.3),s:rnd(.4,1)})}
  for(let i=0,n=q>1?38:18;i<n;i++){const p=spot(T,4,80);if(p)P.glints.push({x:p[0],y:p[1],p:rnd(0,6.3),s:rnd(.5,1.3)})}
  for(let i=0,n=q>1?6:3;i<n;i++){const p=spot(T,16,500);if(p)P.ships.push({x:p[0],y:p[1],a:rnd(0,6.28),w:0,sp:rnd(5,9),p:rnd(0,6.3),tr:[],tt:0,k:i})}
  for(let i=0,n=q>1?5:3;i<n;i++)P.clouds.push({x:rnd(-100,T.PW),y:rnd(0,T.PH-60),v:rnd(3,7),s:rnd(.8,1.6),a:rnd(.06,.12),k:i%3});
  for(let i=0,n=q>1?22:10;i<n;i++)P.motes.push({x:rnd(0,T.PW),y:rnd(0,T.PH),vx:rnd(1,5),vy:rnd(-7,-2),p:rnd(0,6.3),s:rnd(.4,1.1)});
};
FX.sync=function(m,cur){
  if(!this.cv||typeof TC==='undefined'||!TC||!S)return;
  const T=TC;if(this.seed!==T.seed+':'+T.PW)this.build(T);
  const W=S.W,cap=window.__CAP||{};this.cities=[];this.emit=[];this.flags=[];
  const capPts=Object.values(cap);
  S.n.forEach(n=>{if(!n.alive)return;(n.cities||[]).forEach(j=>{const o=S.own[j];if(o<0)return;const own=S.n[o],x=(j%W+.5)*K,y=((j/W|0)+.5)*K;
    if(capPts.some(p=>Math.abs(p[0]-x)<24&&Math.abs(p[1]-y)<22))return;
    this.cities.push({x,y,o,col:own.col});
    const ind=S.yr>=1800&&(own.tech>=30||own.res>=60);if(this.emit.length<26)this.emit.push({x:x+4,y:y-7,ind,acc:Math.random(),r:ind?1.9:.8})})});
  Object.keys(cap).forEach(o=>{const n=S.n[o];if(!n||!n.alive)return;const p=cap[o];this.flags.push({x:p[0]+.5,y:p[1]-6,col:n.col,mine:!!(m&&m.id==n.id),o:+o,p:+o*1.7});
    const ind=S.yr>=1800&&(n.tech>=30||n.res>=60);if(this.emit.length<30)this.emit.push({x:p[0]+5,y:p[1]-8,ind,acc:Math.random(),r:ind?2.4:1})});
  this.cur=cur?cur.id:-1;this.cap=cap;
};
FX.hit=function(i,col,kind){if(!S||!this.cv)return;const W=S.W;if(this.hits.length>36)this.hits.shift();
  this.hits.push({x:(i%W+.5)*K,y:((i/W|0)+.5)*K,t0:this.t,col,kind,sp:Array.from({length:9},(_,k)=>({a:k/9*6.28+rnd(-.3,.3),v:rnd(18,40)}))})};
function rgbOf(col){try{if(/^hsl/.test(col)){const[r,g,b]=hsl(col);return[r,g,b]}}catch(e){}if(/^#/.test(col))return hex(col);return[240,200,120]}
function houses(g,c){const x=c.x,y=c.y;g.fillStyle='rgba(8,12,24,.28)';g.beginPath();g.ellipse(x,y+2.4,9,2.6,0,0,7);g.fill();
  const rc=rgbOf(c.col),roof=`rgb(${rc[0]*.7|0},${rc[1]*.7|0},${rc[2]*.7|0})`;
  [[-5.5,1.2,.9],[0,-.4,1.15],[5.5,1.2,.9]].forEach(([dx,dy,s])=>{const bx=x+dx,by=y+dy;g.fillStyle='#ece1c4';g.fillRect(bx-2.2*s,by-3*s,4.4*s,3.6*s);
    g.fillStyle=roof;g.beginPath();g.moveTo(bx-3.2*s,by-2.8*s);g.lineTo(bx,by-6*s);g.lineTo(bx+3.2*s,by-2.8*s);g.closePath();g.fill();
    g.strokeStyle='rgba(10,14,26,.55)';g.lineWidth=.7;g.strokeRect(bx-2.2*s,by-3*s,4.4*s,3.6*s)})}
function ship(g,s,t){const d=Math.cos(s.a)>=0?1:-1,by=Math.sin(t*1.3+s.p)*.6;
  if(s.tr.length>2){g.lineCap='round';g.beginPath();g.moveTo(s.tr[0][0],s.tr[0][1]);for(let i=1;i<s.tr.length;i++)g.lineTo(s.tr[i][0],s.tr[i][1]);g.strokeStyle='rgba(235,246,255,.16)';g.lineWidth=2.2;g.stroke();
    g.beginPath();const h=s.tr.length>>1;g.moveTo(s.tr[h][0],s.tr[h][1]);for(let i=h+1;i<s.tr.length;i++)g.lineTo(s.tr[i][0],s.tr[i][1]);g.strokeStyle='rgba(235,246,255,.18)';g.lineWidth=1.2;g.stroke()}
  g.save();g.translate(s.x,s.y+by);g.scale(d,1);g.fillStyle='rgba(0,10,30,.28)';g.beginPath();g.ellipse(0,3.4,6.5,1.5,0,0,7);g.fill();
  g.fillStyle='#4a3322';g.beginPath();g.moveTo(-5.5,-.2);g.lineTo(5.5,-.2);g.lineTo(3.6,2.7);g.lineTo(-3.6,2.7);g.closePath();g.fill();
  g.strokeStyle='#2a1b10';g.lineWidth=.9;g.beginPath();g.moveTo(.2,-8.5);g.lineTo(.2,-.2);g.stroke();
  g.fillStyle='#f3ead2';g.beginPath();g.moveTo(.9,-8);g.lineTo(.9,-1);g.lineTo(5,-1);g.closePath();g.fill();
  g.fillStyle='#e2d6b6';g.beginPath();g.moveTo(-.5,-6);g.lineTo(-.5,-1);g.lineTo(-3.8,-1);g.closePath();g.fill();
  g.fillStyle='#d7a64a';g.fillRect(-.4,-9.3,2.3,1.1);g.restore()}
function flag(g,f,t){const x=f.x,y=f.y,w=f.mine?14:11,h=f.mine?8:6.4,N=7,top=y-12;
  g.strokeStyle='#2b2118';g.lineWidth=1.1;g.beginPath();g.moveTo(x,y);g.lineTo(x,top-1);g.stroke();
  const wv=i=>Math.sin(t*4.4-i*.85+f.p)*1.5*(i/N);
  g.beginPath();g.moveTo(x,top);for(let i=1;i<=N;i++)g.lineTo(x+i*w/N,top+wv(i));for(let i=N;i>=0;i--)g.lineTo(x+i*w/N,top+h+wv(i));g.closePath();
  g.fillStyle=f.col;g.fill();g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=.7;g.stroke();
  g.beginPath();g.moveTo(x,top+h*.42);for(let i=1;i<=N;i++)g.lineTo(x+i*w/N,top+h*.42+wv(i));g.lineTo(x+w,top+h*.62+wv(N));for(let i=N;i>=0;i--)g.lineTo(x+i*w/N,top+h*.62+wv(i));g.closePath();g.fillStyle='rgba(255,236,190,.55)';g.fill();
  g.fillStyle='#e6b755';g.beginPath();g.arc(x,top-1.4,1.2,0,7);g.fill()}
function bird(g,b,t){const f=Math.sin(t*9+b.p);g.beginPath();g.moveTo(b.x-4.2,b.y+f*2.2);g.quadraticCurveTo(b.x-2,b.y-1.6-f*1.2,b.x,b.y);g.quadraticCurveTo(b.x+2,b.y-1.6-f*1.2,b.x+4.2,b.y+f*2.2);g.stroke()}
function update(dt){
  const T=FX.T,q=FX.Q;FX.t+=dt;const t=FX.t;
  FX.ships.forEach(s=>{s.w+=(Math.random()-.5)*dt*1.6;s.w=clamp(s.w,-.35,.35);s.a+=s.w*dt;const nx=s.x+Math.cos(s.a)*s.sp*dt,ny=s.y+Math.sin(s.a)*s.sp*dt;
    if(wat9(T,nx,ny,13)){s.x=nx;s.y=ny}else{s.a+=(Math.random()<.5?1:-1)*rnd(.9,2.4);s.w=0}
    s.tt+=dt;if(s.tt>.4){s.tt=0;s.tr.push([s.x-Math.cos(s.a)*4,s.y-Math.sin(s.a)*4]);if(s.tr.length>14)s.tr.shift()}});
  FX.clouds.forEach(c=>{c.x+=c.v*dt;if(c.x>T.PW+20)c.x=-270*c.s});
  FX.motes.forEach(m=>{m.x+=m.vx*dt;m.y+=m.vy*dt;if(m.y<-4){m.y=T.PH+4;m.x=rnd(0,T.PW)}if(m.x>T.PW+4)m.x=-4});
  FX.nextBird-=dt;if(FX.nextBird<=0&&q>0){FX.nextBird=rnd(14,26);const L=Math.random()<.5,y0=rnd(T.PH*.12,T.PH*.7),n=RI?(2+(Math.random()*3|0)):3,fl=[];
    for(let i=0;i<n;i++)fl.push({dx:i*rnd(10,15),dy:(i%2?1:-1)*i*rnd(3,6),p:rnd(0,6)});FX.birds.push({x:L?-20:T.PW+20,y:y0,vx:(L?1:-1)*rnd(30,44),vy:rnd(-3,3),fl,age:0})}
  FX.birds.forEach(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt+Math.sin(t*1.3)*.2;b.age+=dt});FX.birds=FX.birds.filter(b=>b.x>-60&&b.x<T.PW+60);
  /* humo */
  const cap=q>1?90:36;
  if(FX.smoke.length<cap)FX.emit.forEach(e=>{e.acc+=dt*e.r*(q>1?1:.5);while(e.acc>=1&&FX.smoke.length<cap){e.acc-=1;FX.smoke.push({x:e.x+rnd(-.8,.8),y:e.y,vx:rnd(2,6),vy:-rnd(5,10),l:0,m:rnd(2.4,3.8),r:rnd(2.5,3.8),ind:e.ind})}});
  for(let i=FX.smoke.length-1;i>=0;i--){const p=FX.smoke[i];p.l+=dt;if(p.l>=p.m){FX.smoke.splice(i,1);continue}p.x+=(p.vx+Math.sin(t*.8+p.y*.05)*2)*dt;p.y+=p.vy*dt;p.r+=dt*4.2}
  FX.hits=FX.hits.filter(h=>t-h.t0<1.5);
}
function draw(){
  const g=FX.x,T=FX.T,t=FX.t,q=FX.Q;g.clearRect(0,0,T.PW,T.PH);
  /* agua: olas + destellos */
  g.lineWidth=1;g.lineCap='round';
  FX.waves.forEach(w=>{const a=.05+.13*(.5+.5*Math.sin(t*w.s+w.p));g.strokeStyle=`rgba(200,228,255,${a.toFixed(3)})`;const x=w.x+Math.sin(t*.25+w.p)*3.5,y=w.y,l=w.l;
    g.beginPath();g.moveTo(x-l/2,y);g.quadraticCurveTo(x-l/4,y-2.2,x,y);g.quadraticCurveTo(x+l/4,y+2.2,x+l/2,y);g.stroke()});
  FX.glints.forEach(s=>{const a=Math.pow(Math.max(0,Math.sin(t*s.s+s.p)),7)*.9;if(a>.04){g.fillStyle=`rgba(255,246,216,${a.toFixed(3)})`;g.fillRect(s.x-3,s.y-.5,6,1);g.fillRect(s.x-.5,s.y-3,1,6)}});
  FX.ships.forEach(s=>ship(g,s,t));
  FX.cities.forEach(c=>houses(g,c));
  /* humo */
  FX.smoke.forEach(p=>{const k=p.l/p.m,a=(k<.15?k/.15:1-(k-.15)/.85)*(p.ind?.55:.42);g.globalAlpha=clamp(a,0,1);const s=p.r*2;g.drawImage(p.ind?SP.puffD:SP.puffL,p.x-s/2,p.y-s/2,s,s)});g.globalAlpha=1;
  FX.flags.forEach(f=>flag(g,f,t));
  /* turno actual + selección + guerras */
  if(FX.cap&&FX.cap[FX.cur]){const p=FX.cap[FX.cur],r=14+Math.sin(t*2.4)*1.6;g.strokeStyle=`rgba(239,208,138,${(.45+.25*Math.sin(t*2.4)).toFixed(3)})`;g.lineWidth=1.4;g.beginPath();g.arc(p[0],p[1],r,0,7);g.stroke()}
  if(typeof selC!=='undefined'&&selC!=null&&S){const W=S.W,x=(selC%W)*K,y=(selC/W|0)*K,a=.5+.4*Math.sin(t*3.2);g.strokeStyle=`rgba(255,236,190,${a.toFixed(3)})`;g.lineWidth=2;g.strokeRect(x+1.5,y+1.5,K-3,K-3);
    g.fillStyle=`rgba(239,208,138,${(.06+.05*Math.sin(t*3.2)).toFixed(3)})`;g.fillRect(x+1.5,y+1.5,K-3,K-3)}
  if(S&&S.wf&&FX.cap)Object.values(S.wf).forEach((w,i)=>{const p=FX.cap[w.A],r=FX.cap[w.B];if(!p||!r)return;for(let u=0;u<2;u++){const f=(t*.11+u*.5+i*.17)%1,x=p[0]+(r[0]-p[0])*f,y=p[1]+(r[1]-p[1])*f;g.globalAlpha=.55+.4*Math.sin(t*9+u);g.drawImage(SP.ember,x-7,y-7,14,14)}});g.globalAlpha=1;
  /* aves */
  g.strokeStyle='rgba(14,20,34,.62)';g.lineWidth=1.25;FX.birds.forEach(b=>b.fl.forEach(f=>bird(g,{x:b.x-Math.sign(b.vx)*f.dx,y:b.y+f.dy,p:f.p},t)));
  /* nubes (suaves) */
  FX.clouds.forEach(c=>{g.globalAlpha=c.a;g.drawImage(SP.cloud[c.k],c.x,c.y,260*c.s,120*c.s)});g.globalAlpha=1;
  /* partículas ambientales */
  FX.motes.forEach(m=>{const a=(.5+.5*Math.sin(t*m.s+m.p))*.38;g.fillStyle=`rgba(255,232,170,${a.toFixed(3)})`;g.beginPath();g.arc(m.x,m.y,1.1,0,7);g.fill()});
  /* conquistas */
  FX.hits.forEach(h=>{const age=(t-h.t0),k=age/1.5,c=h.col,r=rgbOf(c);
    g.globalAlpha=clamp(.7*(1-k*1.6),0,1);g.drawImage(SP.flash,h.x-26,h.y-26,52,52);g.globalAlpha=1;
    for(let j=0;j<2;j++){const kk=clamp((age-j*.18)/1.1,0,1);if(kk<=0||kk>=1)continue;g.strokeStyle=`rgba(${r[0]},${r[1]},${r[2]},${(1-kk).toFixed(3)})`;g.lineWidth=.6+2.8*(1-kk);g.beginPath();g.arc(h.x,h.y,5+ease(kk)*34,0,7);g.stroke()}
    if(age<1.2){g.fillStyle=`rgba(255,244,214,${(1-age/1.2).toFixed(3)})`;h.sp.forEach(s=>{g.fillRect(h.x+Math.cos(s.a)*s.v*age*1.2-1,h.y+Math.sin(s.a)*s.v*age*1.2+14*age*age-1,2,2)})}});
}
function loop(ts){
  requestAnimationFrame(loop);
  try{
    const gm=$q('#game');if(FX.Q<=0||document.hidden||!gm||gm.hidden||!FX.vis||!FX.T||!FX.x||typeof S==='undefined'||!S){FX.last=ts;return}
    let dt=(ts-FX.last)/1000;FX.last=ts;FX.acc+=Math.min(dt,.1);if(FX.acc<.032)return;dt=FX.acc;FX.acc=0;
    const c0=performance.now();update(dt);draw();const c=performance.now()-c0;FX.cost=FX.cost*.92+c*.08;
    FX.fr++;if(dt>.075)FX.slow++;
    if(FX.fr>=120){if((FX.cost>5||FX.slow>40)&&FX.Q>1){FX.Q=1;FX.build(FX.T)}FX.fr=0;FX.slow=0}
  }catch(e){FX.err=e;FX.Q=0;console.warn('fx off',e)}
}

/* ============ números con easing, barras animadas, destellos ============ */
const NV={},BV={},TW=[];let twOn=false;
function parse(t){const m=t.match(/^([^\d]*)(\d[\d.,]*)([\s\S]*)$/);if(!m)return null;const n=m[2];let th=/^\d{1,3}(\.\d{3})+$/.test(n),v,dec=0;
  if(th)v=parseInt(n.replace(/\./g,''),10);else{v=parseFloat(n.replace(',','.'));const d=n.split(/[.,]/)[1];dec=d?d.length:0}
  if(!isFinite(v))return null;return{pre:m[1],suf:m[3],v,th,dec}}
const fmtv=(p,v)=>p.pre+(p.th?Math.round(v).toLocaleString('es'):v.toFixed(p.dec))+p.suf;
function twLoop(now){const keep=[];TW.forEach(w=>{if(!w.el.isConnected)return;const k=clamp((now-w.t0)/w.d,0,1);w.n.nodeValue=fmtv(w.p,w.a+(w.b-w.a)*ease(k));if(k<1)keep.push(w)});
  TW.length=0;keep.forEach(w=>TW.push(w));if(TW.length)requestAnimationFrame(twLoop);else twOn=false}
function sparkle(el){if(RM||!el)return;for(let i=0;i<6;i++){const s=document.createElement('i');s.className='sp';const a=rnd(0,6.28),d=rnd(14,30);s.style.setProperty('--dx',Math.cos(a)*d+'px');s.style.setProperty('--dy',Math.sin(a)*d-8+'px');s.style.animationDelay=rnd(0,.15)+'s';el.appendChild(s);setTimeout(()=>s.remove(),1100)}}
function flash(el,cls){if(!el)return;el.classList.remove('gain','loss');void el.offsetWidth;el.classList.add(cls);setTimeout(()=>el.classList.remove(cls),950)}
let introDone=false;
function numbers(){
  const L=[...document.querySelectorAll('#top .rs b')].map((e,i)=>['t'+i,e,e.parentNode,true]).concat([...document.querySelectorAll('#me>div:not([style])>b')].map((e,i)=>['m'+i,e,e.parentNode,false]));
  L.forEach(([k,el,box,top])=>{const n=el.firstChild;if(!n||n.nodeType!==3||el.childNodes.length!==1)return;const p=parse(n.nodeValue);if(!p)return;const pv=NV[k];NV[k]={v:p.v};
    let from=null;if(pv&&pv.v!==p.v)from=pv.v;else if(!pv&&!introDone&&top)from=0;
    if(from===null||RM)return;
    n.nodeValue=fmtv(p,from);TW.push({el,n,p,a:from,b:p.v,t0:performance.now(),d:pv?750:1100});
    if(pv){if(p.v>pv.v){flash(box,'gain');if(top)sparkle(box)}else flash(box,'loss')}});
  introDone=true;if(TW.length&&!twOn){twOn=true;requestAnimationFrame(twLoop)}
}
function bars(){
  const L=[...document.querySelectorAll('#me [style*="grid-column"]>div>div')].map((e,i)=>['b'+i,e]).concat([...document.querySelectorAll('#vp .bar i')].map((e,i)=>['v'+i,e]));
  L.forEach(([k,el])=>{const tg=parseFloat(el.style.width)||0,pv=BV[k];BV[k]=tg;if(RM)return;const from=pv===undefined?0:pv;if(from===tg)return;
    el.style.transition='none';el.style.width=from+'%';void el.offsetWidth;el.classList.add('barfx');el.style.transition='';
    requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style.width=tg+'%'}));
    if(tg>from){el.classList.add('bump');setTimeout(()=>el.classList.remove('bump'),1100)}})
}

/* ============ turnos y conquistas ============ */
let lastKey=null,PO=null,POseed=null;
function watch(m,cur,my){
  const key=S.r+'-'+S.t;
  if(key!==lastKey){lastKey=key;if(my&&!S.win)banner('Tu turno','Año '+S.yr+' · Ronda '+S.r)}
  if(POseed!==S.seed){PO=null;POseed=S.seed}
  if(PO&&PO.length===S.own.length){let mine=0,lost=0,tot=0;const ch=[];
    for(let i=0;i<S.own.length;i++){const a=PO[i],b=S.own[i];if(a!==b&&a>=0&&b>=0){tot++;ch.push(i);if(m&&b===m.id)mine++;if(m&&a===m.id)lost++}}
    ch.slice(0,14).forEach(i=>{const o=S.n[S.own[i]];FX.hit(i,m&&o&&o.id===m.id?'#efd08a':(o?o.col:'#ffffff'))});
    if(mine)toast(mine>1?'¡'+mine+' provincias conquistadas!':'¡Provincia conquistada!');
    if(lost)toast(lost>1?'Has perdido '+lost+' provincias':'Has perdido una provincia',true)}
  PO=S.own.slice();
}
function post(){
  try{
    const gm=$q('#game');if(!gm||gm.hidden||typeof S==='undefined'||!S)return;
    FX.init();
    const m=S.n.find(n=>n.peer==me),cur=S.n[S.t],my=!!m&&!!cur&&cur.peer==me&&!S.win;
    FX.sync(m,cur);numbers();bars();watch(m,cur,my);
  }catch(e){FX.err=e;console.warn('polish',e)}
}
const _rg=renderGame;renderGame=function(){_rg.apply(this,arguments);post()};
const be=$q('#bEnd');if(be)be.addEventListener('click',()=>{if(be.disabled)return;be.classList.remove('ending');void be.offsetWidth;be.classList.add('ending');banner('Fin del turno','Los reinos mueven sus fichas');setTimeout(()=>be.classList.remove('ending'),700)});
})();
