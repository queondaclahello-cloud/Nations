import re,shutil,os
SRC='/home/claude/nop/nations-of-power-pwa'
OUT='/home/claude/work/out/nations-of-power-pwa'
os.makedirs(OUT,exist_ok=True)
t=open(SRC+'/index.html',encoding='utf-8').read()
def rep(a,b,cnt=1):
    global t
    assert t.count(a)>=1,('missing',a[:60])
    t=t.replace(a,b,cnt)
# --- parches mínimos de dibujo (solo presentación) ---
rep("const cur=S.n[S.t],CAP={};","const cur=S.n[S.t],CAP=window.__CAP={};")
rep("x.font='10px sans-serif';x.fillStyle='#ffd25a';x.strokeText('⚔'+Math.round(pw(n)),X,Y+30);x.fillText('⚔'+Math.round(pw(n)),X,Y+30)",
    "x.font='600 10px sans-serif';x.fillStyle='#efd08a';x.strokeText(Math.round(pw(n)),X,Y+30);x.fillText(Math.round(pw(n)),X,Y+30)")
rep("x.font='18px serif';x.fillText('⚔',(p[0]+q[0])/2,(p[1]+q[1])/2+6)",
    "(window.__ico&&__ico(x,'⚔',(p[0]+q[0])/2,(p[1]+q[1])/2,20,'#f6dede','#ff8a8a'))||(x.font='18px serif',x.fillText('⚔',(p[0]+q[0])/2,(p[1]+q[1])/2+6))")
rep("x.font='24px serif';x.fillText(e.i,(e.c%W+.5)*K,((e.c/W|0)+.5)*K)",
    "(window.__ico&&__ico(x,e.i,(e.c%W+.5)*K,((e.c/W|0)+.5)*K,26))||(x.font='24px serif',x.fillText(e.i,(e.c%W+.5)*K,((e.c/W|0)+.5)*K))")
rep("x.fillText(ICON[k],s,s+2);","(window.__ico&&__ico(x,ICON[k],s,s+2,34,'#f4ead0','#e6b755'))||x.fillText(ICON[k],s,s+2);")
# brújula más fina
rep("x.strokeStyle=x.fillStyle='#f5e6b0';x.lineWidth=2;x.font='bold 13px Georgia'","x.strokeStyle=x.fillStyle='rgba(245,230,176,.8)';x.lineWidth=1.2;x.font='600 12px Georgia'")
# --- inyección de CSS/JS ---
css=open('skin.css',encoding='utf-8').read()
js=open('icons.js',encoding='utf-8').read()+'\n'+open('polish.js',encoding='utf-8').read()
rep("</style></head>","\n/*SKIN*/\n"+css+"\n</style></head>")
i=t.rindex("</script></body></html>")
t=t[:i]+"\n/*POLISH*/\n"+js+"\n"+t[i:]
open(OUT+'/index.html','w',encoding='utf-8').write(t)
for f in ['manifest.webmanifest','icon-192.png','icon-512.png','LEEME.txt']:
    shutil.copy(SRC+'/'+f,OUT+'/'+f)
sw=open(SRC+'/sw.js',encoding='utf-8').read().replace("'nop-v1'","'nop-v2'")
open(OUT+'/sw.js','w',encoding='utf-8').write(sw)
print('ok',len(t))
