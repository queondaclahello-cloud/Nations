/* ===== Set de iconos unificado: trazo fino + detalle dorado ===== */
const NOPI={
swords:['<path d="M3.5 3.500 15 15M20.500 3.500 9 15M15 15l4.500 4.500M9 15l-4.500 4.500"/>','<path d="M13 17l4-4M11 17l-4-4"/><circle cx="19.5" cy="19.5" r="1" fill="#000"/><circle cx="4.5" cy="19.5" r="1" fill="#000"/>'],
dagger:['<path d="M12 2.8 14.3 12H9.7Z"/><path d="M12 12v6"/>','<path d="M8 12h8"/><circle cx="12" cy="20" r="1.5"/>'],
helmet:['<path d="M5 14.500a7 7 0 0 1 14 0V20h-3.500v-4H8.500v4H5z"/>','<path d="M8.500 5.500c2.200-1.700 4.800-1.700 7 0M12 9.500v6"/>'],
shield:['<path d="M12 3 19.5 6v6c0 4.5-3.5 7.5-7.5 9-4-1.5-7.5-4.5-7.5-9V6Z"/>','<path d="M12 7.5v9M8.2 11.8h7.6"/>'],
handshake:['<path d="M2.5 9H6l3.5-1.5H13L16 9.5l5.5-.5"/><path d="M2.5 9v5H6l5.5 4.5c1 .8 2.4.5 3-.5l6-4V9"/>','<path d="M9 12.5l3 2.5M11.5 11l2.8 2.5"/>'],
microscope:['<path d="M9 3.5l4 2-2.5 5-4-2Z"/><path d="M12.5 8.5c4 .5 6 3.5 5.5 7-.4 2.5-3 4-6 4"/><path d="M6 21h12"/>','<path d="M5.5 17h6"/><path d="M7.4 11.7l1.3.7"/>'],
clipboard:['<path d="M7.5 5.5h-2v15h13v-15h-2"/><path d="M8.5 12h7M8.5 15.5H13"/>','<path d="M9 3.5h6v4H9z"/>'],
columns:['<path d="M3 9l9-5 9 5z"/><path d="M6 11.5v5.5M10 11.5v5.5M14 11.5v5.5M18 11.5v5.5"/>','<path d="M3.5 20.5h17M5 18h14"/>'],
scroll:['<path d="M6 5a2 2 0 0 1 2-2h11v12.5H8a2 2 0 0 0-2 2z"/><path d="M6 17.5A2.5 2.5 0 0 0 8.5 20h9.5a2 2 0 0 0 2-2v-2.5"/>','<path d="M10 7h6M10 10.5h6"/>'],
skull:['<path d="M12 3.5c-4.5 0-7 3-7 6.5 0 2.500 1.300 4 2.500 5v3.500h9V15c1.200-1 2.500-2.500 2.500-5 0-3.500-2.500-6.500-7-6.500z"/>','<circle cx="9.3" cy="10.5" r="1.4" fill="#000"/><circle cx="14.7" cy="10.5" r="1.4" fill="#000"/><path d="M10.5 18.500V16M13.500 18.500V16"/>'],
exchange:['<path d="M4 8.5h15M20 15.5H5"/>','<path d="M16 5.500l3 3-3 3M8 12.500l-3 3 3 3"/>'],
dove:['<path d="M3 12.500c3-2 5-1.500 7-.5 0-3.500 2.500-6.500 6-7-.5 2 0 3 1 3.500 2 0 3.500-1 4.500-1.500-.5 2.500-2 4.500-4 5 -.5 3.500-3.500 6.500-8 6-1.500-.2-3-1.200-3.500-2.700z"/>','<circle cx="16.500" cy="7.500" r=".9" fill="#000"/><path d="M21 7.500l1.500.5"/>'],
coin:['<circle cx="12" cy="12" r="8.500"/>','<path d="M9.200 9.700c.8-1.300 4.300-1.500 5.400 0M9.200 14.300c.8 1.300 4.600 1.500 5.600 0M12 7.500v9"/>'],
scales:['<path d="M12 4v16M7 20h10M5 7.500h14"/>','<path d="M5 7.500l-2.200 6h4.400zM19 7.500l-2.200 6h4.400z"/>'],
user:['<circle cx="12" cy="8" r="3.500"/><path d="M5 20c0-4 3-6 7-6s7 2 7 6"/>','<path d="M9.500 18.500h5"/>'],
map:['<path d="M3.500 6.500 9 4.500l6 2 5.500-2v13l-5.500 2-6-2-5.500 2z"/>','<path d="M9 4.500v13M15 6.500v13"/>'],
rocket:['<path d="M12 2.800c3.500 2.700 4.500 6.700 4 11.700H8c-.5-5 .5-9 4-11.700z"/><path d="M8 12l-3 4.500h3M16 12l3 4.500h-3"/>','<path d="M10.500 17.500 12 21.500l1.500-4"/><circle cx="12" cy="9" r="1.600"/>'],
warning:['<path d="M12 3.500 21.500 19.500h-19z"/>','<path d="M12 9.500V14"/><circle cx="12" cy="16.800" r=".9" fill="#000"/>'],
globe:['<circle cx="12" cy="12" r="8.500"/><path d="M3.500 12h17"/>','<path d="M12 3.500c-3 3.500-3 13 0 17M12 3.500c3 3.500 3 13 0 17"/>'],
users:['<circle cx="9" cy="8.500" r="3"/><path d="M3.500 19c0-3.500 2.500-5 5.500-5s5.500 1.500 5.500 5"/>','<circle cx="16.500" cy="9.500" r="2.400"/><path d="M16.500 14c2.500 0 4 1.500 4 4.500"/>'],
pickaxe:['<path d="M4.500 20 14 10.500"/>','<path d="M8 7c3.500-3 8.500-2.500 11.500 1l-2 1c-2-2-5-2.500-7.500-.5z"/>'],
news:['<path d="M5 5h13.500v13.500A1.500 1.500 0 0 1 17 20H6.500A1.500 1.500 0 0 1 5 18.500zM18.500 9H21v9a2 2 0 0 1-2 2"/>','<path d="M8 8.500h6M8 12h7.500M8 15.500h7.500"/>'],
quill:['<path d="M20 4c-6 0-11.500 4-13 11l-2 4 4-2c7-1.500 11-7 11-13z"/>','<path d="M5 20l6-7"/>'],
ban:['<circle cx="12" cy="12" r="8.500"/>','<path d="M6 6l12 12"/>'],
burst:['<path d="M12 2.500 14 8l5.500-2.500-3 5 5 1.500-5 1.500 3 5L14 16l-2 5.500L10 16l-5.500 2.500 3-5-5-1.500 5-1.500-3-5L10 8z"/>','<circle cx="12" cy="12" r="2"/>'],
city:['<path d="M3.500 20.500V11H9v9.500M9 20.500V5.500h6v15M15 20.500V9.500h5.500v11M2.500 20.500h19"/>','<path d="M11 9h2M11 12.500h2M11 16h2M17 13h1.500M17 16.500h1.500"/>'],
play:['<path d="M8 5l11 7-11 7z"/>',''],
skip:['<path d="M5 5.500 14 12l-9 6.500z"/>','<path d="M17.500 5.500v13"/>'],
speaker:['<path d="M4 9.500h4L13 5.500v13L8 14.500H4z"/>','<path d="M16 9c1.500 1.500 1.500 4.500 0 6M18.500 6.500c3 3 3 8 0 11"/>'],
mute:['<path d="M4 9.500h4L13 5.500v13L8 14.500H4z"/>','<path d="M16 9.500l5 5M21 9.500l-5 5"/>'],
gift:['<path d="M4.500 10.500h15V20h-15zM3.500 7.500h17v3h-17z"/>','<path d="M12 7.500V20M12 7.500C10 3.500 6.500 4 7.500 6.500 8 7.500 10 7.500 12 7.500s4 0 4.500-1C17.500 4 14 3.500 12 7.500"/>'],
hands:['<path d="M3 11c0 5 4 8.500 9 8.500s9-3.500 9-8.500M3 11l3-2M21 11l-3-2"/>','<circle cx="12" cy="9" r="2.600"/>'],
fist:['<path d="M7 11V8.500a1.500 1.500 0 0 1 3 0V8a1.500 1.500 0 0 1 3 0v.5a1.500 1.500 0 0 1 3 0v1a1.500 1.500 0 0 1 3 0V14c0 4-2.500 6-6 6h-1.500c-3 0-5-2.500-5-5.500V12z"/>','<path d="M10 12.500h7"/>'],
factory:['<path d="M3.500 20.500v-10L9 14v-3.500L14.500 14V8h6v12.500zM16 8V4h3v4"/>','<path d="M6.500 17h1.500M11 17h1.500M16 17h1.500"/>'],
plug:['<path d="M8 3.500V8M16 3.500V8M6 8h12v4a6 6 0 0 1-12 0z"/>','<path d="M12 18v3.500"/>'],
crown:['<path d="M4 17.500 3.500 8l5 4 3.500-6.500 3.500 6.500 5-4-.5 9.500z"/>','<path d="M4 20.500h16"/><circle cx="3.500" cy="7" r="1" fill="#000"/><circle cx="12" cy="4.500" r="1" fill="#000"/><circle cx="20.500" cy="7" r="1" fill="#000"/>'],
check:['<path d="M5 12.500l5 5 9.500-11"/>',''],
ballot:['<path d="M4.500 11h15v9h-15zM8 11V4.500h8V11"/>','<path d="M9 14.500h6M10 7.800l1.500 1.400 2.500-3"/>'],
virus:['<circle cx="12" cy="12" r="4.500"/>','<path d="M12 3v3.500M12 17.500V21M3 12h3.500M17.500 12H21M5.600 5.600 8 8M16 16l2.400 2.400M18.400 5.600 16 8M8 16l-2.400 2.400"/>'],
mask:['<path d="M4 5.500c4 2 12 2 16 0V12c0 4.500-3.500 8-8 8s-8-3.500-8-8z"/>','<path d="M7.500 10.500q2 1.500 3.500 0M13 10.500q1.500 1.500 3.500 0M9 15q3 2 6 0"/>'],
gear:['<path d="M12 2.500 13.600 5 16.400 4.100 17 6.900 19.800 7.600 18.900 10.300 21 12 18.900 13.700 19.800 16.400 17 17.100 16.400 19.900 13.600 19 12 21.500 10.400 19 7.600 19.900 7 17.100 4.200 16.400 5.100 13.700 3 12 5.100 10.300 4.200 7.600 7 6.900 7.600 4.100 10.400 5z"/>','<circle cx="12" cy="12" r="3"/>'],
book:['<path d="M12 6C10 4.500 6.500 4.500 4 5.500v13c2.500-1 6-1 8 .5 2-1.500 5.500-1.500 8-.5v-13C17.500 4.500 14 4.500 12 6z"/>','<path d="M12 6v13"/>'],
install:['<path d="M7 3.500h10v17H7z"/>','<path d="M12 8v6M9.200 11.500l2.800 2.800 2.800-2.800"/>'],
wheel:['<circle cx="12" cy="12" r="8.500"/><path d="M12 3.500v17M3.500 12h17M6 6l12 12M18 6 6 18"/>','<circle cx="12" cy="12" r="2.200" fill="#000"/>'],
trophy:['<path d="M7.500 4h9v6a4.500 4.500 0 0 1-9 0zM7.500 6h-3C4.500 9 5.500 10.500 7.800 11M16.500 6h3c0 3-1 4.500-3.300 5M12 14.500V18"/>','<path d="M8.500 20.500h7M12 18v2.500"/>'],
chat:['<path d="M4.500 5.500h15v10H11L7 19v-3.500H4.500z"/>','<circle cx="8.500" cy="10.500" r=".9" fill="#000"/><circle cx="12" cy="10.500" r=".9" fill="#000"/><circle cx="15.500" cy="10.500" r=".9" fill="#000"/>'],
eye:['<path d="M2.500 12c2.500-4.500 6-6.500 9.500-6.500s7 2 9.500 6.500c-2.500 4.500-6 6.500-9.500 6.500S5 16.500 2.500 12z"/>','<circle cx="12" cy="12" r="3"/>'],
mail:['<path d="M3.500 6h17v12h-17z"/>','<path d="M3.500 6.500 12 13l8.500-6.500"/>'],
dice:['<rect x="5" y="5" width="14" height="14" rx="3"/>','<g fill="#000"><circle cx="9" cy="9" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="9" cy="15" r="1"/><circle cx="15" cy="15" r="1"/></g>'],
calendar:['<rect x="4" y="5.500" width="16" height="14.500" rx="2"/><path d="M8 3.500v4M16 3.500v4"/>','<path d="M4 10.500h16"/><g fill="#000"><circle cx="8.500" cy="14.500" r=".9"/><circle cx="12" cy="14.500" r=".9"/><circle cx="15.500" cy="14.500" r=".9"/></g>'],
timer:['<circle cx="12" cy="13.500" r="7.500"/><path d="M10 3.500h4"/>','<path d="M12 13.500V9.500M12 13.500l2.500-1.500"/>'],
wind:['<path d="M3.500 7H17a2.500 2.500 0 1 0-2.500-2.500M3.500 11.500H20a2.500 2.500 0 1 1-2.500 2.500"/>','<path d="M3.500 16H12a2 2 0 1 1-2 2"/>'],
volcano:['<path d="M3 20.500 9.500 10h5L21 20.500z"/>','<path d="M12 3v4M8.500 5l1.200 2.500M15.500 5l-1.200 2.500"/>'],
wave:['<path d="M2.500 9c2.500-3 4.500-3 6.500 0s4 3 6 0 4.500-3 6.500 0"/>','<path d="M2.500 15c2.500-3 4.500-3 6.500 0s4 3 6 0 4.500-3 6.500 0"/>'],
sun:['<circle cx="12" cy="12" r="4"/>','<path d="M12 2.500V5M12 19v2.500M2.500 12H5M19 12h2.500M5.300 5.300 7 7M17 17l1.700 1.700M18.700 5.300 17 7M7 17l-1.700 1.700"/>'],
flame:['<path d="M12 2.800c1 3.700 6 6.200 6 11.200 0 3.800-2.700 6.500-6 6.500S6 17.800 6 14c0-2.500 1.500-4 2.500-5.500.7 1.500 1.500 2 2.200 2 1-2 .8-5 1.300-7.700z"/>','<path d="M12 20.500c-1.700 0-2.700-1.500-2.500-3.200.2-1.500 1.500-2.300 2.500-3.800 1 1.500 2.500 2.300 2.500 4 0 1.700-1 3-2.500 3z"/>'],
chart:['<path d="M3.500 4v16h17"/>','<path d="M6.500 15 11 10.500l3 3 5.500-6M15.500 7.500h4v4"/>'],
oil:['<path d="M12 3c3.500 5 6 8 6 11.500 0 3.500-2.700 6-6 6s-6-2.500-6-6C6 11 8.500 8 12 3z"/>','<path d="M9.500 15c0 1.500 1 2.500 2.500 2.800"/>'],
megaphone:['<path d="M4 10h4l8.500-4.500v13L8 14H4zM8 14l1 5.500h2.500L10.500 15"/>','<path d="M19 9.500c1.200 1.500 1.200 3.500 0 5"/>'],
barrier:['<path d="M3 8h18v6H3zM6 14v6M18 14v6"/>','<path d="M8 8l-2.500 6M13 8l-2.500 6M18 8l-2.500 6"/>'],
palette:['<path d="M12 3.500c-5 0-8.500 4-8.500 8.500s3.500 8.500 8 8.500c1.700 0 2.300-1.300 1.500-2.500s0-2.500 1.500-2.500h3c2 0 3-1.500 3-3.500 0-4.500-3.500-8.500-8.500-8.500z"/>','<g fill="#000"><circle cx="8" cy="10" r="1.200"/><circle cx="12" cy="7.500" r="1.200"/><circle cx="16" cy="10" r="1.200"/></g>'],
wheat:['<path d="M12 21V8"/>','<path d="M12 12c-2.500-.5-3.700-2-4-4 2 .3 3.600 1.600 4 4M12 12c2.500-.5 3.700-2 4-4-2 .3-3.600 1.600-4 4M12 17c-2.500-.5-3.700-2-4-4 2 .3 3.600 1.600 4 4M12 17c2.500-.5 3.700-2 4-4-2 .3-3.600 1.600-4 4M12 8c-1-1.500-1-3 0-4.500 1 1.500 1 3 0 4.500z"/>'],
laptop:['<path d="M5.500 6h13v9.500h-13zM2.500 18.500h19l-2-3h-15z"/>','<path d="M9 9.500l2 1.500-2 1.500M13 12.500h2.500"/>'],
umbrella:['<path d="M3.500 12C3.500 7 7.500 4 12 4s8.500 3 8.500 8z"/><path d="M12 12v6.500a2 2 0 0 1-4 0"/>','<path d="M8 12c0-2.500 1.800-5 4-8 2.200 3 4 5.500 4 8"/>'],
cap:['<path d="M2.500 9.500 12 5l9.500 4.500L12 14z"/><path d="M6.500 11.500V16c1.500 1.800 9.500 1.800 11 0v-4.500"/>','<path d="M21 10v5"/>'],
thermo:['<path d="M10 14V5.500a2 2 0 0 1 4 0V14a4 4 0 1 1-4 0z"/>','<path d="M12 9v7.500"/><circle cx="12" cy="17" r="1.500" fill="#000"/>'],
star:['<path d="M12 3.500 14.600 9l5.900.7-4.400 4.100 1.200 5.900-5.300-2.900-5.300 2.900 1.200-5.900L3.500 9.700 9.400 9z"/>','<circle cx="12" cy="12" r="1.300" fill="#000"/>'],
cross:['<path d="M6 6l12 12M18 6 6 18"/>',''],
bell:['<path d="M6 17c1-1.500 1.500-3.500 1.500-6 0-3.200 1.800-5.500 4.500-5.500s4.500 2.300 4.500 5.500c0 2.500.5 4.500 1.500 6z"/><path d="M12 3.500v2"/>','<path d="M10 19.500a2 2 0 0 0 4 0"/>'],
info:['<circle cx="12" cy="12" r="8.500"/>','<path d="M12 11v5.500"/><circle cx="12" cy="7.800" r=".9" fill="#000"/>']
};
const NOPE={'⚔':'swords','🗡':'dagger','🪖':'helmet','🛡':'shield','🤝':'handshake','🔬':'microscope','📋':'clipboard','🏛':'columns','🏦':'columns','📜':'scroll','☠':'skull','💱':'exchange','🕊':'dove','💰':'coin','💸':'coin','⚖':'scales','👤':'user','🗺':'map','🚀':'rocket','⚠':'warning','🌐':'globe','🌍':'globe','👥':'users','⛏':'pickaxe','📰':'news','🧠':'quill','🚫':'ban','⛔':'ban','💥':'burst','🏙':'city','▶':'play','🔊':'speaker','🔇':'mute','🎁':'gift','🤲':'hands','😠':'fist','✊':'fist','🏭':'factory','🔌':'plug','👑':'crown','✔':'check','✅':'check','🗳':'ballot','🦠':'virus','🎭':'mask','⚙':'gear','📖':'book','⏯':'play','⏭':'skip','📲':'install','🎰':'wheel','🏆':'trophy','💬':'chat','👁':'eye','🕵':'eye','📨':'mail','🎲':'dice','📅':'calendar','⏱':'timer','🌪':'wind','🌋':'volcano','🌊':'wave','☀':'sun','🔥':'flame','📈':'chart','⛽':'oil','🛢':'oil','📢':'megaphone','🚧':'barrier','🎨':'palette','🌾':'wheat','💻':'laptop','🏖':'umbrella','🎓':'cap','🌡':'thermo','⭐':'star','🌟':'star','❌':'cross','✖':'cross','🔔':'bell','ℹ':'info'};
(function(){
  const svg=(inner,stroke)=>"data:image/svg+xml,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="${stroke}" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`);
  let css='';
  for(const k in NOPI){const[m,g]=NOPI[k];css+=`.ic[data-i="${k}"]{--m:url("${svg(m,'#000')}");--g:url("${svg(g||'<path d="M0 0"/>','#000')}")}\n`}
  const st=document.createElement('style');st.id='nop-icons';st.textContent=css;document.head.appendChild(st);
  window.NOPI=NOPI;window.NOPE=NOPE;
  /* canvas: imágenes a color (trazo crema + detalle dorado) */
  const IMG={};
  function getImg(n,M,G){const k=n+'|'+M+'|'+G;let im=IMG[k];if(!im){im=IMG[k]=new Image();const[a,b]=NOPI[n];
    im.src="data:image/svg+xml,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"><g stroke="${M}">${a}</g><g stroke="${G}">${b.replace(/fill="#000"/g,`fill="${G}"`)}</g></svg>`)}return im}
  window.__ico=function(x,e,cx,cy,sz,main,gold){
    const n=NOPE[(e||'').replace(/\ufe0f/g,'')];if(!n||!NOPI[n])return false;
    const im=getImg(n,main||'#f4ead0',gold||'#e6b755');
    if(!im.complete||!im.naturalWidth)return false;
    x.save();x.shadowColor='rgba(0,0,0,.75)';x.shadowBlur=4;x.drawImage(im,cx-sz/2,cy-sz/2,sz,sz);x.restore();return true};
  Object.keys(NOPI).forEach(n=>getImg(n,'#f4ead0','#e6b755'));
  /* sustitución de emojis en el DOM, conservando el texto para textContent */
  const keys=Object.keys(NOPE).sort((a,b)=>b.length-a.length).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
  const RX=new RegExp('('+keys.join('|')+')[\\ufe0f\\u20e3]?','gu'),TEST=new RegExp(keys.join('|'),'u'),EMO=new RegExp('('+keys.join('|')+')[\\ufe0f]?\\s*','gu');
  const SKIP=/^(OPTION|SCRIPT|STYLE|TEXTAREA|INPUT|CANVAS|TITLE)$/;
  function mk(e){const n=NOPE[e];const s=document.createElement('span');s.className='ic';s.dataset.i=n;s.setAttribute('aria-hidden','true');const t=document.createElement('span');t.className='ie';t.textContent=e;s.appendChild(t);return s}
  function conv(root){
    const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentNode;return(p&&!SKIP.test(p.nodeName)&&!(p.classList&&p.classList.contains('ie'))&&TEST.test(n.nodeValue))?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}}),L=[];let n;while(n=w.nextNode())L.push(n);
    L.forEach(t=>{const s=t.nodeValue,f=document.createDocumentFragment();let last=0,m;RX.lastIndex=0;
      while(m=RX.exec(s)){if(m.index>last)f.appendChild(document.createTextNode(s.slice(last,m.index)));f.appendChild(mk(m[1]));last=m.index+m[0].length;if(s[last]===' ')last++}
      if(last<s.length)f.appendChild(document.createTextNode(s.slice(last)));t.parentNode.replaceChild(f,t)});
    root.querySelectorAll&&root.querySelectorAll('option').forEach(o=>{const v=o.textContent.replace(EMO,'').trim();if(v!==o.textContent)o.textContent=v});
  }
  window.__nopConv=conv;
  let q=new Set(),raf=0;
  const mo=new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData'){const p=m.target.parentNode;p&&p.nodeType===1&&q.add(p)}else m.addedNodes.forEach(n=>{n.nodeType===1?q.add(n):(n.nodeType===3&&n.parentNode&&q.add(n.parentNode))})}
    if(!raf)raf=requestAnimationFrame(()=>{raf=0;const L=[...q];q.clear();mo.disconnect();try{L.forEach(r=>{if(r.isConnected&&!(r.classList&&r.classList.contains('ie')))conv(r)})}finally{mo.takeRecords();mo.observe(document.body,{childList:true,subtree:true,characterData:true})}})});
  conv(document.body);mo.observe(document.body,{childList:true,subtree:true,characterData:true});
})();
