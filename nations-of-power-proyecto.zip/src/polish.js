/* ===== polish.js · capa de vida y feedback (no altera mecánicas) ===== */
(function(){
const $q=s=>document.querySelector(s),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a);
const RM=!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
const ease=t=>1-Math.pow(1-t,3);
function hex(c){c=(c||'#d7a64a').replace('#','');if(c.length==3)c=c.replace(/./g,'$&$&');return[0,2,4].map(i=>parseInt(c.substr(i,2),16)||0)}
function mixc(a,b,t){const A=hex(a),B=hex(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}

/* --- tema: el acento deja de cambiar de color por pantalla; siempre azul + oro (o el color elegido) --- */
applyTheme=function(id){scr=id||scr;const r=document.documentElement.style,c=(typeof thc!=='undefined'&&thc!='auto')?thc:'#d7a64a';
  r.setProperty('--ac',c);r.setProperty('--ac-hi',mixc(c,'#ffffff',.34));r.setProperty('--ac-lo',mixc(c,'#000000',.34));r.setProperty('--bg','#0a1020')};
try{applyTheme()}catch(e){}

/* --- andamiaje DOM --- */
const bn=document.createElement('div');bn.id='banner';bn.innerHTML='<h2></h2><p></p>';document.body.appendChild(bn);
const ts=document.createElement('div');ts.id='toast';document.body.appendChild(ts);
function banner(t,s){const h=bn.querySelector('h2'),p=bn.querySelector('p');h.textContent=t;p.textContent=s||'';bn.classList.remove('show');void bn.offsetWidth;bn.classList.add('show')}
function toast(t,bad){const d=document.createElement('div');if(bad)d.className='bad';d.textContent=t;ts.appendChild(d);if(window.__nopConv)__nopConv(d);setTimeout(()=>d.remove(),3100);while(ts.children.length>3)ts.firstChild.remove()}

/* ============ EFECTOS DEL MAPA (capa canvas superpuesta) ============ */
const FX={Q:RM?0:2,cost:0,err:null,cv:null,x:null,W:0,H:0,seed:null,waves:[],glints:[],ships:[],birds:[],clouds:[],smoke:[],emit:[],flags:[],cities:[],motes:[],hits:[],
  t:0,acc:0,last:0,nextBird:5,fr:0,slow:0,vis:true,pcs:null};
window.__nopfx=FX;
function spr(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);return c}
const SP={
 puffD:spr(48,48,(g,w)=>{const r=g.createRadialGradient(24,24,0,24,24,24);r.addColorStop(0,'rgba(78,84,100,.75)');r.addColorStop(.6,'rgba(78,84,100,.28)');r.addColorStop(1,'rgba(78,84,100,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 puffL:spr(48,48,(g,w)=>{const r=g.createRadialGradient(24,24,0,24,24,24);r.addColorStop(0,'rgba(232,236,244,.7)');r.addColorStop(.6,'rgba(232,236,244,.25)');r.addColorStop(1,'rgba(232,236,244,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 ember:spr(24,24,(g,w)=>{const r=g.createRadialGradient(12,12,0,12,12,12);r.addColorStop(0,'rgba(255,214,150,.95)');r.addColorStop(.35,'rgba(255,110,70,.55)');r.addColorStop(1,'rgba(255,80,50,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 flash:spr(64,64,(g,w)=>{const r=g.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,255,255,.9)');r.addColorStop(.4,'rgba(255,255,255,.3)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,w,w)}),
 cloud:[0,1,2].map(k=>spr(260,120,(g,w,h)=>{for(let i=0;i<9;i++){const cx=40+Math.random()*(w-80),cy=h*.55+(Math.random()-.5)*28,r=24+Math.random()*30,q=g.createRadialGradient(cx,cy,0,cx,cy,r);q.addColorStop(0,'rgba(255,255,255,.55)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(cx-r,cy-r,r*2,r*2)}}))
};
FX.init=function(){
  if(this.cv)return;const mw=$q('.mw'),map=$q('#map');if(!mw||!map)return;
  const c=document.createElement('canvas');c.id='fx';c.setAttribute('aria-hidden','true');mw.insertBefore(c,map.nextSibling);this.cv=c;this.x=c.getContext('2d');
  if('IntersectionObserver'in window)new IntersectionObserver(e=>{FX.vis=e[0].isIntersecting}).observe(map);
  requestAnimationFrame(ts=>{FX.last=ts;loop(ts)});
};
const wat=(T,x,y)=>x>=0&&y>=0&&x<T.PW&&y<T.PH&&T.pc[(y|0)*T.PW+(x|0)]<0;
const wat9=(T,x,y,r)=>wat(T,x,y)&&wat(T,x+r,y)&&wat(T,x-r,y)&&wat(T,x,y+r)&&wat(T,x,y-r)&&wat(T,x+r*.7,y+r*.7)&&wat(T,x-r*.7,y-r*.7);
function spot(T,r,tries){for(let i=0;i<(tries||600);i++){const x=rnd(r,T.PW-r),y=rnd(r,T.PH-r);if(wat9(T,x,y,r))return[x,y]}return null}
FX.build=function(T){
  this.T=T;this.seed=T.seed+':'+T.PW;this.W=T.PW;this.H=T.PH;this.cv.width=T.PW;this.cv.height=T.PH;
  const q=this.Q,P=this;P.waves=[];P.glints=[];P.ships=[];P.clouds=[];P.motes=[];P.birds=[];
  for(let i=0,n=q>1?80:40;i<n;i++){const p=spot(T,7,80);if(p)P.waves.push({x:p[0],y:p[1],l:rnd(8,17),p:rnd(0,6.3),s:rnd(.4,1)})}
  for(let i=0,n=q>1?38:18;i<n;i++){const p=spot(T,4,80);if(p)P.glints.push({x:p[0],y:p[1],p:rnd(0,6.3),s:rnd(.5,1.3)})}
  for(let i=0,n=q>1?6:3;i<n;i++){const p=spot(T,16,500);if(p)P.ships.push({x:p[0],y:p[1],a:rnd(0,6.28),w:0,sp:rnd(5,9),p:rnd(0,6.3),tr:[],tt:0,k:i})}
  for(let i=0,n=q>1?5:3;i<n;i++)P.clouds.push({x:rnd(-100,T.PW),y:rnd(0,T.PH-60),v:rnd(3,7),s:rnd(.8,1.6),a:rnd(.06,.12),k:i%3});
  for(let i=0,n=q>1?22:10;i<n;i++)P.motes.push({x:rnd(0,T.PW),y:rnd(0,T.PH),vx:rnd(1,5),vy:rnd(-7,-2),p:rnd(0,6.3),s:rnd(.4,1.1)});
};
FX.sync=function(m,cur){
  if(!this.cv||typeof TC==='undefined'||!TC||!S)return;
  const T=TC;if(this.seed!==T.seed+':'+T.PW)this.build(T);
  const W=S.W,cap=window.__CAP||{};this.cities=[];this.emit=[];this.flags=[];
  const capPts=Object.values(cap);
  S.n.forEach(n=>{if(!n.alive)return;(n.cities||[]).forEach(j=>{const o=S.own[j];if(o<0)return;const own=S.n[o],x=(j%W+.5)*K,y=((j/W|0)+.5)*K;
    if(capPts.some(p=>Math.abs(p[0]-x)<24&&Math.abs(p[1]-y)<22))return;
    this.cities.push({x,y,o,col:own.col});
    const ind=S.yr>=1800&&(own.tech>=30||own.res>=60);if(this.emit.length<26)this.emit.push({x:x+4,y:y-7,ind,acc:Math.random(),r:ind?1.9:.8})})});
  Object.keys(cap).forEach(o=>{const n=S.n[o];if(!n||!n.alive)return;const p=cap[o];this.flags.push({x:p[0]+.5,y:p[1]-6,col:n.col,mine:!!(m&&m.id==n.id),o:+o,p:+o*1.7});
    const ind=S.yr>=1800&&(n.tech>=30||n.res>=60);if(this.emit.length<30)this.emit.push({x:p[0]+5,y:p[1]-8,ind,acc:Math.random(),r:ind?2.4:1})});
  this.cur=cur?cur.id:-1;this.cap=cap;
};
FX.hit=function(i,col,kind){if(!S||!this.cv)return;const W=S.W;if(this.hits.length>36)this.hits.shift();
  this.hits.push({x:(i%W+.5)*K,y:((i/W|0)+.5)*K,t0:this.t,col,kind,sp:Array.from({length:9},(_,k)=>({a:k/9*6.28+rnd(-.3,.3),v:rnd(18,40)}))})};
function rgbOf(col){try{if(/^hsl/.test(col)){const[r,g,b]=hsl(col);return[r,g,b]}}catch(e){}if(/^#/.test(col))return hex(col);return[240,200,120]}
function houses(g,c){const x=c.x,y=c.y;g.fillStyle='rgba(8,12,24,.28)';g.beginPath();g.ellipse(x,y+2.4,9,2.6,0,0,7);g.fill();
  const rc=rgbOf(c.col),roof=`rgb(${rc[0]*.7|0},${rc[1]*.7|0},${rc[2]*.7|0})`;
  [[-5.5,1.2,.9],[0,-.4,1.15],[5.5,1.2,.9]].forEach(([dx,dy,s])=>{const bx=x+dx,by=y+dy;g.fillStyle='#ece1c4';g.fillRect(bx-2.2*s,by-3*s,4.4*s,3.6*s);
    g.fillStyle=roof;g.beginPath();g.moveTo(bx-3.2*s,by-2.8*s);g.lineTo(bx,by-6*s);g.lineTo(bx+3.2*s,by-2.8*s);g.closePath();g.fill();
    g.strokeStyle='rgba(10,14,26,.55)';g.lineWidth=.7;g.strokeRect(bx-2.2*s,by-3*s,4.4*s,3.6*s)})}
function ship(g,s,t){const d=Math.cos(s.a)>=0?1:-1,by=Math.sin(t*1.3+s.p)*.6;
  if(s.tr.length>2){g.lineCap='round';g.beginPath();g.moveTo(s.tr[0][0],s.tr[0][1]);for(let i=1;i<s.tr.length;i++)g.lineTo(s.tr[i][0],s.tr[i][1]);g.strokeStyle='rgba(235,246,255,.16)';g.lineWidth=2.2;g.stroke();
    g.beginPath();const h=s.tr.length>>1;g.moveTo(s.tr[h][0],s.tr[h][1]);for(let i=h+1;i<s.tr.length;i++)g.lineTo(s.tr[i][0],s.tr[i][1]);g.strokeStyle='rgba(235,246,255,.18)';g.lineWidth=1.2;g.stroke()}
  g.save();g.translate(s.x,s.y+by);g.scale(d,1);g.fillStyle='rgba(0,10,30,.28)';g.beginPath();g.ellipse(0,3.4,6.5,1.5,0,0,7);g.fill();
  g.fillStyle='#4a3322';g.beginPath();g.moveTo(-5.5,-.2);g.lineTo(5.5,-.2);g.lineTo(3.6,2.7);g.lineTo(-3.6,2.7);g.closePath();g.fill();
  g.strokeStyle='#2a1b10';g.lineWidth=.9;g.beginPath();g.moveTo(.2,-8.5);g.lineTo(.2,-.2);g.stroke();
  g.fillStyle='#f3ead2';g.beginPath();g.moveTo(.9,-8);g.lineTo(.9,-1);g.lineTo(5,-1);g.closePath();g.fill();
  g.fillStyle='#e2d6b6';g.beginPath();g.moveTo(-.5,-6);g.lineTo(-.5,-1);g.lineTo(-3.8,-1);g.closePath();g.fill();
  g.fillStyle='#d7a64a';g.fillRect(-.4,-9.3,2.3,1.1);g.restore()}
function flag(g,f,t){const x=f.x,y=f.y,w=f.mine?14:11,h=f.mine?8:6.4,N=7,top=y-12;
  g.strokeStyle='#2b2118';g.lineWidth=1.1;g.beginPath();g.moveTo(x,y);g.lineTo(x,top-1);g.stroke();
  const wv=i=>Math.sin(t*4.4-i*.85+f.p)*1.5*(i/N);
  g.beginPath();g.moveTo(x,top);for(let i=1;i<=N;i++)g.lineTo(x+i*w/N,top+wv(i));for(let i=N;i>=0;i--)g.lineTo(x+i*w/N,top+h+wv(i));g.closePath();
  g.fillStyle=f.col;g.fill();g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=.7;g.stroke();
  g.beginPath();g.moveTo(x,top+h*.42);for(let i=1;i<=N;i++)g.lineTo(x+i*w/N,top+h*.42+wv(i));g.lineTo(x+w,top+h*.62+wv(N));for(let i=N;i>=0;i--)g.lineTo(x+i*w/N,top+h*.62+wv(i));g.closePath();g.fillStyle='rgba(255,236,190,.55)';g.fill();
  g.fillStyle='#e6b755';g.beginPath();g.arc(x,top-1.4,1.2,0,7);g.fill()}
function bird(g,b,t){const f=Math.sin(t*9+b.p);g.beginPath();g.moveTo(b.x-4.2,b.y+f*2.2);g.quadraticCurveTo(b.x-2,b.y-1.6-f*1.2,b.x,b.y);g.quadraticCurveTo(b.x+2,b.y-1.6-f*1.2,b.x+4.2,b.y+f*2.2);g.stroke()}
function update(dt){
  const T=FX.T,q=FX.Q;FX.t+=dt;const t=FX.t;
  FX.ships.forEach(s=>{s.w+=(Math.random()-.5)*dt*1.6;s.w=clamp(s.w,-.35,.35);s.a+=s.w*dt;const nx=s.x+Math.cos(s.a)*s.sp*dt,ny=s.y+Math.sin(s.a)*s.sp*dt;
    if(wat9(T,nx,ny,13)){s.x=nx;s.y=ny}else{s.a+=(Math.random()<.5?1:-1)*rnd(.9,2.4);s.w=0}
    s.tt+=dt;if(s.tt>.4){s.tt=0;s.tr.push([s.x-Math.cos(s.a)*4,s.y-Math.sin(s.a)*4]);if(s.tr.length>14)s.tr.shift()}});
  FX.clouds.forEach(c=>{c.x+=c.v*dt;if(c.x>T.PW+20)c.x=-270*c.s});
  FX.motes.forEach(m=>{m.x+=m.vx*dt;m.y+=m.vy*dt;if(m.y<-4){m.y=T.PH+4;m.x=rnd(0,T.PW)}if(m.x>T.PW+4)m.x=-4});
  FX.nextBird-=dt;if(FX.nextBird<=0&&q>0){FX.nextBird=rnd(14,26);const L=Math.random()<.5,y0=rnd(T.PH*.12,T.PH*.7),n=RI?(2+(Math.random()*3|0)):3,fl=[];
    for(let i=0;i<n;i++)fl.push({dx:i*rnd(10,15),dy:(i%2?1:-1)*i*rnd(3,6),p:rnd(0,6)});FX.birds.push({x:L?-20:T.PW+20,y:y0,vx:(L?1:-1)*rnd(30,44),vy:rnd(-3,3),fl,age:0})}
  FX.birds.forEach(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt+Math.sin(t*1.3)*.2;b.age+=dt});FX.birds=FX.birds.filter(b=>b.x>-60&&b.x<T.PW+60);
  /* humo */
  const cap=q>1?90:36;
  if(FX.smoke.length<cap)FX.emit.forEach(e=>{e.acc+=dt*e.r*(q>1?1:.5);while(e.acc>=1&&FX.smoke.length<cap){e.acc-=1;FX.smoke.push({x:e.x+rnd(-.8,.8),y:e.y,vx:rnd(2,6),vy:-rnd(5,10),l:0,m:rnd(2.4,3.8),r:rnd(2.5,3.8),ind:e.ind})}});
  for(let i=FX.smoke.length-1;i>=0;i--){const p=FX.smoke[i];p.l+=dt;if(p.l>=p.m){FX.smoke.splice(i,1);continue}p.x+=(p.vx+Math.sin(t*.8+p.y*.05)*2)*dt;p.y+=p.vy*dt;p.r+=dt*4.2}
  FX.hits=FX.hits.filter(h=>t-h.t0<1.5);
}
function draw(){
  const g=FX.x,T=FX.T,t=FX.t,q=FX.Q;g.clearRect(0,0,T.PW,T.PH);
  /* agua: olas + destellos */
  g.lineWidth=1;g.lineCap='round';
  FX.waves.forEach(w=>{const a=.05+.13*(.5+.5*Math.sin(t*w.s+w.p));g.strokeStyle=`rgba(200,228,255,${a.toFixed(3)})`;const x=w.x+Math.sin(t*.25+w.p)*3.5,y=w.y,l=w.l;
    g.beginPath();g.moveTo(x-l/2,y);g.quadraticCurveTo(x-l/4,y-2.2,x,y);g.quadraticCurveTo(x+l/4,y+2.2,x+l/2,y);g.stroke()});
  FX.glints.forEach(s=>{const a=Math.pow(Math.max(0,Math.sin(t*s.s+s.p)),7)*.9;if(a>.04){g.fillStyle=`rgba(255,246,216,${a.toFixed(3)})`;g.fillRect(s.x-3,s.y-.5,6,1);g.fillRect(s.x-.5,s.y-3,1,6)}});
  FX.ships.forEach(s=>ship(g,s,t));
  FX.cities.forEach(c=>houses(g,c));
  /* humo */
  FX.smoke.forEach(p=>{const k=p.l/p.m,a=(k<.15?k/.15:1-(k-.15)/.85)*(p.ind?.55:.42);g.globalAlpha=clamp(a,0,1);const s=p.r*2;g.drawImage(p.ind?SP.puffD:SP.puffL,p.x-s/2,p.y-s/2,s,s)});g.globalAlpha=1;
  FX.flags.forEach(f=>flag(g,f,t));
  /* turno actual + selección + guerras */
  if(FX.cap&&FX.cap[FX.cur]){const p=FX.cap[FX.cur],r=14+Math.sin(t*2.4)*1.6;g.strokeStyle=`rgba(239,208,138,${(.45+.25*Math.sin(t*2.4)).toFixed(3)})`;g.lineWidth=1.4;g.beginPath();g.arc(p[0],p[1],r,0,7);g.stroke()}
  if(typeof selC!=='undefined'&&selC!=null&&S){const W=S.W,x=(selC%W)*K,y=(selC/W|0)*K,a=.5+.4*Math.sin(t*3.2);g.strokeStyle=`rgba(255,236,190,${a.toFixed(3)})`;g.lineWidth=2;g.strokeRect(x+1.5,y+1.5,K-3,K-3);
    g.fillStyle=`rgba(239,208,138,${(.06+.05*Math.sin(t*3.2)).toFixed(3)})`;g.fillRect(x+1.5,y+1.5,K-3,K-3)}
  if(S&&S.wf&&FX.cap)Object.values(S.wf).forEach((w,i)=>{const p=FX.cap[w.A],r=FX.cap[w.B];if(!p||!r)return;for(let u=0;u<2;u++){const f=(t*.11+u*.5+i*.17)%1,x=p[0]+(r[0]-p[0])*f,y=p[1]+(r[1]-p[1])*f;g.globalAlpha=.55+.4*Math.sin(t*9+u);g.drawImage(SP.ember,x-7,y-7,14,14)}});g.globalAlpha=1;
  /* aves */
  g.strokeStyle='rgba(14,20,34,.62)';g.lineWidth=1.25;FX.birds.forEach(b=>b.fl.forEach(f=>bird(g,{x:b.x-Math.sign(b.vx)*f.dx,y:b.y+f.dy,p:f.p},t)));
  /* nubes (suaves) */
  FX.clouds.forEach(c=>{g.globalAlpha=c.a;g.drawImage(SP.cloud[c.k],c.x,c.y,260*c.s,120*c.s)});g.globalAlpha=1;
  /* partículas ambientales */
  FX.motes.forEach(m=>{const a=(.5+.5*Math.sin(t*m.s+m.p))*.38;g.fillStyle=`rgba(255,232,170,${a.toFixed(3)})`;g.beginPath();g.arc(m.x,m.y,1.1,0,7);g.fill()});
  /* conquistas */
  FX.hits.forEach(h=>{const age=(t-h.t0),k=age/1.5,c=h.col,r=rgbOf(c);
    g.globalAlpha=clamp(.7*(1-k*1.6),0,1);g.drawImage(SP.flash,h.x-26,h.y-26,52,52);g.globalAlpha=1;
    for(let j=0;j<2;j++){const kk=clamp((age-j*.18)/1.1,0,1);if(kk<=0||kk>=1)continue;g.strokeStyle=`rgba(${r[0]},${r[1]},${r[2]},${(1-kk).toFixed(3)})`;g.lineWidth=.6+2.8*(1-kk);g.beginPath();g.arc(h.x,h.y,5+ease(kk)*34,0,7);g.stroke()}
    if(age<1.2){g.fillStyle=`rgba(255,244,214,${(1-age/1.2).toFixed(3)})`;h.sp.forEach(s=>{g.fillRect(h.x+Math.cos(s.a)*s.v*age*1.2-1,h.y+Math.sin(s.a)*s.v*age*1.2+14*age*age-1,2,2)})}});
}
function loop(ts){
  requestAnimationFrame(loop);
  try{
    const gm=$q('#game');if(FX.Q<=0||document.hidden||!gm||gm.hidden||!FX.vis||!FX.T||!FX.x||typeof S==='undefined'||!S){FX.last=ts;return}
    let dt=(ts-FX.last)/1000;FX.last=ts;FX.acc+=Math.min(dt,.1);if(FX.acc<.032)return;dt=FX.acc;FX.acc=0;
    const c0=performance.now();update(dt);draw();const c=performance.now()-c0;FX.cost=FX.cost*.92+c*.08;
    FX.fr++;if(dt>.075)FX.slow++;
    if(FX.fr>=120){if((FX.cost>5||FX.slow>40)&&FX.Q>1){FX.Q=1;FX.build(FX.T)}FX.fr=0;FX.slow=0}
  }catch(e){FX.err=e;FX.Q=0;console.warn('fx off',e)}
}

/* ============ números con easing, barras animadas, destellos ============ */
const NV={},BV={},TW=[];let twOn=false;
function parse(t){const m=t.match(/^([^\d]*)(\d[\d.,]*)([\s\S]*)$/);if(!m)return null;const n=m[2];let th=/^\d{1,3}(\.\d{3})+$/.test(n),v,dec=0;
  if(th)v=parseInt(n.replace(/\./g,''),10);else{v=parseFloat(n.replace(',','.'));const d=n.split(/[.,]/)[1];dec=d?d.length:0}
  if(!isFinite(v))return null;return{pre:m[1],suf:m[3],v,th,dec}}
const fmtv=(p,v)=>p.pre+(p.th?Math.round(v).toLocaleString('es'):v.toFixed(p.dec))+p.suf;
function twLoop(now){const keep=[];TW.forEach(w=>{if(!w.el.isConnected)return;const k=clamp((now-w.t0)/w.d,0,1);w.n.nodeValue=fmtv(w.p,w.a+(w.b-w.a)*ease(k));if(k<1)keep.push(w)});
  TW.length=0;keep.forEach(w=>TW.push(w));if(TW.length)requestAnimationFrame(twLoop);else twOn=false}
function sparkle(el){if(RM||!el)return;for(let i=0;i<6;i++){const s=document.createElement('i');s.className='sp';const a=rnd(0,6.28),d=rnd(14,30);s.style.setProperty('--dx',Math.cos(a)*d+'px');s.style.setProperty('--dy',Math.sin(a)*d-8+'px');s.style.animationDelay=rnd(0,.15)+'s';el.appendChild(s);setTimeout(()=>s.remove(),1100)}}
function flash(el,cls){if(!el)return;el.classList.remove('gain','loss');void el.offsetWidth;el.classList.add(cls);setTimeout(()=>el.classList.remove(cls),950)}
let introDone=false;
function numbers(){
  const L=[...document.querySelectorAll('#top .rs b')].map((e,i)=>['t'+i,e,e.parentNode,true]).concat([...document.querySelectorAll('#me>div:not([style])>b')].map((e,i)=>['m'+i,e,e.parentNode,false]));
  L.forEach(([k,el,box,top])=>{const n=el.firstChild;if(!n||n.nodeType!==3||el.childNodes.length!==1)return;const p=parse(n.nodeValue);if(!p)return;const pv=NV[k];NV[k]={v:p.v};
    let from=null;if(pv&&pv.v!==p.v)from=pv.v;else if(!pv&&!introDone&&top)from=0;
    if(from===null||RM)return;
    n.nodeValue=fmtv(p,from);TW.push({el,n,p,a:from,b:p.v,t0:performance.now(),d:pv?750:1100});
    if(pv){if(p.v>pv.v){flash(box,'gain');if(top)sparkle(box)}else flash(box,'loss')}});
  introDone=true;if(TW.length&&!twOn){twOn=true;requestAnimationFrame(twLoop)}
}
function bars(){
  const L=[...document.querySelectorAll('#me [style*="grid-column"]>div>div')].map((e,i)=>['b'+i,e]).concat([...document.querySelectorAll('#vp .bar i')].map((e,i)=>['v'+i,e]));
  L.forEach(([k,el])=>{const tg=parseFloat(el.style.width)||0,pv=BV[k];BV[k]=tg;if(RM)return;const from=pv===undefined?0:pv;if(from===tg)return;
    el.style.transition='none';el.style.width=from+'%';void el.offsetWidth;el.classList.add('barfx');el.style.transition='';
    requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style.width=tg+'%'}));
    if(tg>from){el.classList.add('bump');setTimeout(()=>el.classList.remove('bump'),1100)}})
}

/* ============ turnos y conquistas ============ */
let lastKey=null,PO=null,POseed=null;
function watch(m,cur,my){
  const key=S.r+'-'+S.t;
  if(key!==lastKey){lastKey=key;if(my&&!S.win)banner('Tu turno','Año '+S.yr+' · Ronda '+S.r)}
  if(POseed!==S.seed){PO=null;POseed=S.seed}
  if(PO&&PO.length===S.own.length){let mine=0,lost=0,tot=0;const ch=[];
    for(let i=0;i<S.own.length;i++){const a=PO[i],b=S.own[i];if(a!==b&&a>=0&&b>=0){tot++;ch.push(i);if(m&&b===m.id)mine++;if(m&&a===m.id)lost++}}
    ch.slice(0,14).forEach(i=>{const o=S.n[S.own[i]];FX.hit(i,m&&o&&o.id===m.id?'#efd08a':(o?o.col:'#ffffff'))});
    if(mine)toast(mine>1?'¡'+mine+' provincias conquistadas!':'¡Provincia conquistada!');
    if(lost)toast(lost>1?'Has perdido '+lost+' provincias':'Has perdido una provincia',true)}
  PO=S.own.slice();
}
function post(){
  try{
    const gm=$q('#game');if(!gm||gm.hidden||typeof S==='undefined'||!S)return;
    FX.init();
    const m=S.n.find(n=>n.peer==me),cur=S.n[S.t],my=!!m&&!!cur&&cur.peer==me&&!S.win;
    FX.sync(m,cur);numbers();bars();watch(m,cur,my);
  }catch(e){FX.err=e;console.warn('polish',e)}
}
const _rg=renderGame;renderGame=function(){_rg.apply(this,arguments);post()};
const be=$q('#bEnd');if(be)be.addEventListener('click',()=>{if(be.disabled)return;be.classList.remove('ending');void be.offsetWidth;be.classList.add('ending');banner('Fin del turno','Los reinos mueven sus fichas');setTimeout(()=>be.classList.remove('ending'),700)});
})();
